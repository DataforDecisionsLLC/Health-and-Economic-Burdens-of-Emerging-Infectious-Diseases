# -*- coding: utf-8 -*-
"""
population.py

Description: Creates a file with populations for each country.

Created: 22 May 2024
Modified: 30 September 2024

Inputs:
    1. country_list.xlsx (created in country_list.py)
    2. country_names.xlsx
    3. WPP2022_POP_F01_1_POPULATION_SINGLE_AGE_BOTH_SEXES.xlsx
    
Outputs:
    1. country_year_population.xlsx
    
Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the file country_list.py. 
       Thus, country_list.py must be run prior to running this program.
"""

# %% load in libraries
import numpy as np 
import pandas as pd

# %% save population data

#load in a list of the countries
country_list = pd.read_excel(".../country_list.xlsx")
countries = country_list["country"].unique()

#loading a dictionary that is used to rename countries
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

# load in historical and projected population data
population_2022 = pd.read_excel(".../WPP2022_POP_F01_1_POPULATION_SINGLE_AGE_BOTH_SEXES.xlsx", sheet_name = "Estimates", skiprows = 16)
population_2050 = pd.read_excel(".../WPP2022_POP_F01_1_POPULATION_SINGLE_AGE_BOTH_SEXES.xlsx", sheet_name = "Medium variant", skiprows = 16)

# standardize the population data
def manage_pop_data(df):
    """
    Load in the raw population data, rename columns and countries, only keep 
    the relevant years, and calculate the total population in each year.

    Parameters
    ----------
    df : data frame
        A data frame containing the raw population data.

    Returns
    -------
    _df : data frame
        A data frame containing the processed population data.

    """
    _df = df.rename(columns={"Region, subregion, country or area *": "country", "Year":"year"})
    _df = _df[_df.country != "Micronesia"]
    _df = _df.replace(country_dict)
    _df = _df[_df.country.isin(countries)]
    _df = _df[(_df["year"] > 1999) & (_df["year"] < 2051)]
    _df.year = _df.year.astype(int)
    _df["tot_pop"] = _df[list(range(0, 100))].sum(axis=1).mul(1000)
    _df = _df[["country", "year", "tot_pop"]]
    _df = _df.sort_values(["country", "year"])
    return _df

# perform the data management on both the historical and projected population data.
population_hist = manage_pop_data(population_2022)
population_proj = manage_pop_data(population_2050)

# combine the processed data into a single file
population_exps = pd.concat([population_hist, population_proj])

# save the output
population_exps.to_excel(".../country_year_population.xlsx", index = False)

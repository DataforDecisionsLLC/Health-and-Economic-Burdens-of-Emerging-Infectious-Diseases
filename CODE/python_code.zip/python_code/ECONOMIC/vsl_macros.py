# -*- coding: utf-8 -*-
"""
vsl_macros.py

Description: Creates all the variables needed to perform the VSL analysis.

Created: 12 April 2024
Modified: 30 September 2024

Inputs:
    1. country_list.xlsx (created in country_list.py)
    2. country_names.xlsx
    3. P_Data_Extract_From_World_Development_Indicators-GNI-GDP-Forex-Forex.xlsx
    4. country_year_population.xlsx (created in population.py)
    5. P_Data_Extract_From_World_Development_Indicators-CPI.xlsx
    6. P_Data_Extract_From_World_Development_Indicators-GDP Deflator-2000_2022.xlsx
    7. P_Data_Extract_From_World_Development_Indicators_Metadata.xlsx
    8. RprtRateXchg_20010331_20231231.xlsx
    9. WPP2022_MORT_F05_1_LIFE_EXPECTANCY_BY_AGE_BOTH_SEXES.xlsx
    10. discounted_LE_age_0_100.dta (created in make_discounted_LE_age_0_100.do)
    
Outputs:
    1. growth_rate_df.xlsx
    2. pcgni_vsl.xlsx
    3. life_exp_vsl.xlsx

Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the programs country_list.py,
       population.py, and make_discounted_LE_age_0_100.do. Thus, those three
       programs must be run prior to running this program.
"""

# %% load in libraries
import pandas as pd
import numpy as np
from scipy.stats import gmean

# %% process data 

#load in a list of the countries
country_list = pd.read_excel(".../country_list.xlsx")
countries = country_list["country"].unique()

#loading a dictionary that is used to rename countries
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

# %% load in and process pcgni

# load in WDI data with GNI, GDP, and two types of foreign exchange rates
wdi = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-GNI-GDP-Forex-Forex.xlsx", skipfooter = 5)

# keep and perform minor processing of the GNI data
pcgni = wdi[wdi["Series Name"] == "GNI (current LCU)"]
pcgni = pcgni[["Country Name"] + [col for col in pcgni.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
pcgni["country"] = pcgni["country"].replace(country_dict)
pcgni.columns = pcgni.columns.str.split(' ').str[0]

# rename columns to indicate their source 
rename_dict = {col: 'wdi_pcgni_' + col for col in pcgni.columns[pcgni.columns.str.startswith('2')]}
pcgni = pcgni.rename(columns = rename_dict)
pcgni = pcgni.replace("..", np.nan)

# reshape the data
pcgni = pd.melt(pcgni, id_vars='country', value_vars=[col for col in pcgni.columns[pcgni.columns.str.startswith('wdi_pcgni_')]])
pcgni = pcgni.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"gni"})

# keep and perform minor processing of the GDP data
pcgdp = wdi[wdi["Series Name"] == "GDP (current LCU)"]
pcgdp = pcgdp[["Country Name"] + [col for col in pcgdp.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
pcgdp["country"] = pcgdp["country"].replace(country_dict)
pcgdp.columns = pcgdp.columns.str.split(' ').str[0]

# rename columns to indicate their source 
rename_dict = {col: 'wdi_pcgdp_' + col for col in pcgdp.columns[pcgdp.columns.str.startswith('2')]}
pcgdp = pcgdp.rename(columns = rename_dict)
pcgdp = pcgdp.replace("..", np.nan)

# reshape the data
pcgdp = pd.melt(pcgdp, id_vars='country', value_vars=[col for col in pcgdp.columns[pcgdp.columns.str.startswith('wdi_pcgdp_')]])
pcgdp = pcgdp.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"gdp"})

# rename the year columns
pcgni['year'] = pcgni['year'].map(lambda x: x.lstrip('wdi_pcgni_')).astype(int)
pcgdp['year'] = pcgdp['year'].map(lambda x: x.lstrip('wdi_pcgdp_')).astype(int)

# assign Cuba a value for GNI and GDP post 2020
pcgni.loc[(pcgni.country == "Cuba") & (pcgni.year > 2020), "gni"] = np.nan
pcgdp.loc[(pcgdp.country == "Cuba") & (pcgdp.year > 2020), "gdp"] = np.nan

# combine the GNI and GDP into a single data frame
gni_gdp = pcgni.merge(pcgdp, on = ["country", "year"], how = "outer")

# get a data frame of only complete data and calculate the country-specific ratio of GNI to GDP
complete_gni_gdp = gni_gdp.dropna()
complete_gni_gdp["ratio"] = complete_gni_gdp["gni"]/complete_gni_gdp["gdp"]
country_gni_gdp_ratios = complete_gni_gdp.groupby("country")["ratio"].mean().reset_index()

# get a data frame of missing GNI but non-missing GDP
nogni_gdp = gni_gdp[(gni_gdp.gni.isna()) & (gni_gdp.gdp.notna())]
nogni_gdp = nogni_gdp.merge(country_gni_gdp_ratios, on = "country", how = "left")

# estimate GNI in these countries by multipling GDP by the ratio calculate above
nogni_gdp["gni"] = nogni_gdp["ratio"]*nogni_gdp["gdp"]

# calculate the ratio at a yearly basis
year_gni_gdp_ratios = complete_gni_gdp.groupby("year")["ratio"].mean().reset_index()

# where there is no ratio for the country, multiply by the year-specific ratio
nogni_gdp2 = nogni_gdp[nogni_gdp.gni.isna()].drop(columns = "ratio")
nogni_gdp2 = nogni_gdp2.merge(year_gni_gdp_ratios, on = "year", how = "left")
nogni_gdp2["gni"] = nogni_gdp2["ratio"]*nogni_gdp2["gdp"]

# combine the empirical and imputed GNI and GDP data
gni_gdp2 = pd.concat([nogni_gdp.dropna(), nogni_gdp2])
gni_gdp2 = gni_gdp2.merge(gni_gdp[["country", "year"]], on = ["country", "year"], how = "right")
gni_gdp = gni_gdp.set_index(["country", "year"]).fillna(gni_gdp2[["country", "year", "gni", "gdp"]].set_index(["country", "year"])).reset_index()

# drop GDP which we no longer need
pcgni_df = gni_gdp.drop(columns = "gdp")

# load in the processed population data
population_exps = pd.read_excel(".../country_year_population.xlsx")

# merge population data with GNI data and divide GNI by pop to get per capita GNI
pcgni_df = pcgni_df.merge(population_exps, on = ["country", "year"], how = "left")
pcgni_df["pcgni_lcu"] = pcgni_df["gni"]/pcgni_df["tot_pop"]

# %% convert to 2022 LCUs

# load in the CPI (inflation) data and perform minor processing
cpi_raw = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-CPI.xlsx", skipfooter=5)
cpi = cpi_raw[["Country Name"] + [col for col in cpi_raw.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
cpi["country"] = cpi["country"].replace(country_dict)
cpi.columns = cpi.columns.str.split(' ').str[0]

# rename columns to indicate the source of the data
rename_dict = {col: 'wdi_cpi_' + col for col in cpi.columns[cpi.columns.str.startswith('2')]}
cpi = cpi.rename(columns = rename_dict)
cpi = cpi.replace("..", np.nan)

# only keep cpi series if they have fewer than 5 missing values
good_cpi = cpi.dropna(thresh=cpi.shape[1]-5)
bad_cpi = cpi[~cpi.index.isin(good_cpi.index)]

# reshape the CPI data
good_cpi = pd.melt(good_cpi, id_vars='country', value_vars=[col for col in good_cpi.columns[good_cpi.columns.str.startswith('wdi_cpi_')]])
good_cpi = good_cpi.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"cpi"})
good_cpi['year'] = good_cpi['year'].map(lambda x: x.lstrip('wdi_cpi_')).astype(int)

# forward fill missing CPI data
for c in good_cpi.country.unique():
    for i in range(len(good_cpi.year.unique())):
        good_cpi.loc[good_cpi["country"] == c, "cpi"] = good_cpi.loc[good_cpi["country"] == c, "cpi"].fillna(
            good_cpi.loc[good_cpi["country"] == c, "cpi"].ffill(limit=1))

# back fill missing CPI data
for c in good_cpi.country.unique():
    for i in range(len(good_cpi.year.unique())):
        good_cpi.loc[good_cpi["country"] == c, "cpi"] = good_cpi.loc[good_cpi["country"] == c, "cpi"].fillna(
            good_cpi.loc[good_cpi["country"] == c, "cpi"].bfill(limit=1))
        
# calculate the ratio of CPI in 2022 to CPI in other years (within a country)
for c in good_cpi.country.unique():
    good_cpi_2022 = good_cpi.loc[(good_cpi["country"] == c) & (good_cpi["year"] == 2022), "cpi"].values[0]
    good_cpi.loc[good_cpi["country"]==c, "inflation_ratio"] = good_cpi_2022/good_cpi.loc[good_cpi["country"]==c, "cpi"]

# load in and do minor processing of the deflator data
deflator_raw = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-GDP Deflator-2000_2022.xlsx", skipfooter = 5)
deflator = deflator_raw[["Country Name", "Series Name"] + [col for col in deflator_raw.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
deflator = deflator[deflator["Series Name"] == "GDP deflator (base year varies by country)"].drop(columns = "Series Name")
deflator["country"] = deflator["country"].replace(country_dict)
deflator.columns = deflator.columns.str.split(' ').str[0]

# rename the columns to indicate the data source
rename_dict = {col: 'wdi_deflator_' + col for col in deflator.columns[deflator.columns.str.startswith('2')]}
deflator = deflator.rename(columns = rename_dict)
deflator = deflator.replace("..", np.nan)

# only keep deflator data for countries without CPI data
deflator = deflator[deflator.country.isin(bad_cpi.country.unique())]

# reshape the deflator data
deflator = pd.melt(deflator, id_vars='country', value_vars=[col for col in deflator.columns[deflator.columns.str.startswith('wdi_deflator_')]])
deflator = deflator.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"deflator"})

# rename the columns and process Cuba
deflator['year'] = deflator['year'].map(lambda x: x.lstrip('wdi_deflator_')).astype(int)
deflator.loc[(deflator.country == "Cuba") & (deflator.year > 2020), "deflator"] = np.nan

# forward fill deflator data
for c in deflator.country.unique():
    deflator.loc[deflator["country"] == c, "deflator"] = deflator.loc[deflator["country"] == c, "deflator"].fillna(
        deflator.loc[deflator["country"] == c, "deflator"].ffill())

# back fill deflator data
for c in deflator.country.unique():
    deflator_2022 = deflator.loc[(deflator["country"] == c) & (deflator["year"] == 2022), "deflator"].values[0]
    deflator.loc[deflator["country"]==c, "inflation_ratio"] = deflator_2022/deflator.loc[deflator["country"]==c, "deflator"]

# combine CPI and deflator data
inflation_data = pd.concat([good_cpi, deflator])

# combine cpi, inflation, and pcgni data
pcgni_df = pcgni_df.merge(inflation_data[["country", "year", "inflation_ratio"]], on = ["country", "year"], how = "left")

# create a function to calculate 2022 PCGNI in non-2022 years
def calc_2022_value(x, measure):
     return x[measure]*(x["inflation_ratio"])

# calculate PCGNI in 2022 LCUs for all years
pcgni_df["pcgni_lcu_2022"] = pcgni_df.apply(lambda x: calc_2022_value(x, "pcgni_lcu"), axis=1)

# calculate the growth rate  
pcgni_df["growth_rate"] = np.nan
for c in pcgni_df.country.unique():
    pcgni_df.loc[pcgni_df["country"] == c, 'growth_rate'] = (pcgni_df.loc[pcgni_df["country"] == c, 'pcgni_lcu_2022'].pct_change(fill_method = "pad") + 1)
    
# calculate the average country-specific growth rate as the geometric mean
country_pcgni_growth_rates = pcgni_df.groupby("country")["growth_rate"].apply(lambda x: gmean(x, nan_policy = "omit")).reset_index()

# add the average growth rate data to the PCGNI data
pcgni_df = pcgni_df.drop(columns = "growth_rate").merge(country_pcgni_growth_rates, on = "country", how = "left")

# calculate missing PCGNI by forward filling, adjusting for growth 
for c in pcgni_df.country.unique():
    for i in range(len(pcgni_df.year.unique())):
        pcgni_df.loc[pcgni_df["country"] == c, "pcgni_lcu_2022"] = pcgni_df.loc[pcgni_df["country"] == c, "pcgni_lcu_2022"].fillna(
            pcgni_df.loc[pcgni_df["country"] == c, "pcgni_lcu_2022"].ffill(limit=1).mul(
                pcgni_df.loc[pcgni_df["country"] == c, "growth_rate"].values[0]))
  
# calculate missing PCGNI by back filling, adjusting for growth     
for c in pcgni_df.country.unique():
    for i in range(len(pcgni_df.year.unique())):
        pcgni_df.loc[pcgni_df["country"] == c, "pcgni_lcu_2022"] = pcgni_df.loc[pcgni_df["country"] == c, "pcgni_lcu_2022"].fillna(
            pcgni_df.loc[pcgni_df["country"] == c, "pcgni_lcu_2022"].bfill(limit=1).div(
                pcgni_df.loc[pcgni_df["country"] == c, "growth_rate"].values[0]))

# create a complete data frame of PCGNI in 2022 LCUs
pcgni_final = pcgni_df[["country", "year", "pcgni_lcu_2022"]].sort_values(["country", "year"]).reset_index(drop = True)
pcgni_final = pcgni_final[pcgni_final.country.isin(countries)]

# %% convert LCUs to USDs

# load in the foreign exchange data and do minor processing
forex = wdi[wdi["Series Name"] == "DEC alternative conversion factor (LCU per US$)"]
forex = forex[["Country Name"] + [col for col in forex.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
forex["country"] = forex["country"].replace(country_dict)
forex.columns = forex.columns.str.split(' ').str[0]

# rename columns to indicate the data source
rename_dict = {col: 'wdi_forex_' + col for col in forex.columns[forex.columns.str.startswith('2')]}
forex = forex.rename(columns = rename_dict)
forex = forex.replace("..", np.nan)

# load in a df of currencies used in the data
country_currency = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators_Metadata.xlsx", sheet_name="Country - Metadata")
country_currency = country_currency[["Short Name", "Currency Unit", "Special Notes"]]
country_currency = country_currency.rename(columns={"Short Name": "country"}).replace(country_dict)
    
# create a list of countries using the US dollar.
usd_countries = country_currency[country_currency["Currency Unit"] == "U.S. dollar"]
usd_country_list = usd_countries.country.unique()

# set foreign exchange rate to 1 for countries using the USD.
for country in usd_country_list:
    forex.loc[forex["country"] == country, "wdi_forex_2000":"wdi_forex_2023"] = 1

# find the missing data in 2022 and 2021 and 2020
missing_forex = forex[(forex["wdi_forex_2020"].isna()) & (forex["wdi_forex_2021"].isna())& (forex["wdi_forex_2022"].isna())]

# find the currency for that data
missing_currencies = country_currency[country_currency.country.isin(missing_forex.country.unique())]

# assign foreign exchange rates based on the above information 
forex.loc[forex["country"] == "Channel Islands", "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Channel Islands", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"].isin(["Faeroe Islands", "Greenland"]), "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Denmark", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"] == "Liechtenstein", "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Switzerland", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"] == "Tuvalu", "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Australia", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"] == "Liberia", "wdi_forex_2000":"wdi_forex_2023"] = 1

#load in a treasury foreign exchange (forex) rate file.
forex_treas = pd.read_excel(".../RprtRateXchg_20010331_20231231.xlsx")

# make columns lowercase font
forex_treas.columns = forex_treas.columns.str.lower()
forex_treas[["country", "currency"]] = forex_treas["country - currency description"].str.rsplit("-", n=1, expand=True)
forex_treas.currency = forex_treas.currency.str.title()
forex_treas.country = forex_treas.country.str.title()

#again perform some renaming of countries.
forex_treas = forex_treas.replace(country_dict)

#only save pertinent dates
forex_treas["date"] = pd.to_datetime(forex_treas["record date"])
forex_treas = forex_treas[(forex_treas["date"] > "2007-12-31") & (forex_treas["date"] <= "2023-12-31")]
forex_treas['month'] = forex_treas['date'].dt.month
forex_treas = forex_treas[forex_treas["month"] == 12]
forex_treas['year'] = forex_treas['date'].dt.year

# use treasury exchange rates to fill in for missing existing exchange rates 
forex.loc[forex["country"] == "Venezuela", "wdi_forex_2022"] = forex_treas.loc[(forex_treas["country"] == "Venezuela") & (forex_treas["currency"] == "Bolivar Soberano") & (forex_treas["year"] == 2022), "exchange rate"].values[0]
forex.loc[forex["country"] == "Turkmenistan", "wdi_forex_2022"] = forex_treas.loc[(forex_treas["country"] == "Turkmenistan") & (forex_treas["currency"] == "New Manat") & (forex_treas["year"] == 2022), "exchange rate"].values[0]
forex.loc[forex["country"] == "Cuba", "wdi_forex_2022"] = forex_treas.loc[(forex_treas["country"] == "Cuba") & (forex_treas["currency"] == "Chavito") & (forex_treas["year"] == 2022), "exchange rate"].values[0]

# reshape the forex data
forex = pd.melt(forex, id_vars='country', value_vars=[col for col in forex.columns[forex.columns.str.startswith('wdi_forex_')]])
forex = forex.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"forex"})

# forward fill in missing exchange rates
for c in forex.country.unique():
    forex.loc[forex["country"] == c, "forex"] = forex.loc[forex["country"] == c, "forex"].fillna(
        forex.loc[forex["country"] == c, "forex"].ffill())

# only keep the 2022 forex
forex['year'] = forex['year'].map(lambda x: x.lstrip('wdi_forex_')).astype(int)
forex = forex[forex["year"] == 2022]

# merge PCGNI data with the forex data
pcgni_final = pcgni_final.merge(forex[["country", "forex"]], on = ["country"], how = "left")

# calculate PCGNI in 2022 USDs by dividing 2022 LCUs by the 2022 foreign exchange rate
pcgni_final["pcgni"] = pcgni_final["pcgni_lcu_2022"]/pcgni_final["forex"]

# South Sudan's data is unreliable. We therefore use Sudan as our best proxy.
for t in pcgni_final.year.unique():
    pcgni_final.loc[(pcgni_final["country"] == "South Sudan") & (pcgni_final["year"] == t), "pcgni"] = pcgni_final.loc[(pcgni_final["country"] == "Sudan") & (pcgni_final["year"] == t), "pcgni"].values[0]

# create a list of countries and fill in the year 2000 to 2023
country_list2 = country_list.loc[country_list.index.repeat(len(pcgni_final.year.unique()))]
country_list2['year'] = np.tile(list(np.arange(2000, 2024)), len(country_list2)//len(list(np.arange(2000, 2024))))

# add the country information and year information to the PCGNI data
pcgni_final = pcgni_final.merge(country_list2[["country", "year", "who_region", "wb_inc_group"]], on = ["country", "year"], how = "outer")

# create a variable for the WHO region-World Bank income group
pcgni_final["who_income"] = pcgni_final[["who_region","wb_inc_group"]].agg('-'.join, axis=1)

# fill in missing data with the group median
for i in pcgni_final.who_income.unique():
    for t in pcgni_final.year.unique():
        pcgni_final.loc[(pcgni_final["who_income"] == i) & (pcgni_final["year"] == t), "pcgni"] = pcgni_final['pcgni'].fillna((pcgni_final.loc[(pcgni_final["who_income"] == i) & (pcgni_final["year"] == t), 'pcgni'].median()))

# fill in missing data with the group median
for i in pcgni_final.wb_inc_group.unique():
    for t in pcgni_final.year.unique():
        pcgni_final.loc[(pcgni_final["wb_inc_group"] == i) & (pcgni_final["year"] == t), "pcgni"] = pcgni_final['pcgni'].fillna((pcgni_final.loc[(pcgni_final["wb_inc_group"] == i) & (pcgni_final["year"] == t), 'pcgni'].median()))

# calculate final growth rates
pcgni_final["growth_rate"] = np.nan
for c in pcgni_final.country.unique():
    pcgni_final.loc[pcgni_final["country"] == c, 'growth_rate'] = (pcgni_final.loc[pcgni_final["country"] == c, 'pcgni'].pct_change(fill_method = "pad") + 1)

# calculate the geometric mean of final growth rates
growth_rate = pcgni_final.groupby("country")["growth_rate"].apply(lambda x: gmean(x, nan_policy = "omit")).reset_index()

# save growth rate output 
growth_rate.to_excel(".../growth_rate_df.xlsx")

# create a final PCGNI data frame
pcgni_vsl = pcgni_final[["country", "year", "pcgni"]]
pcgni_vsl = pcgni_vsl[pcgni_vsl.year != 2023]

# and save the output 
writer = pd.ExcelWriter(".../study_countries_macro_vars.xlsx", engine='openpyxl', mode='a', if_sheet_exists="replace")
pcgni_vsl.to_excel(writer, sheet_name = 'pcgni_vsl', index = False)
writer.close()

pcgni_vsl.to_excel('pcgni_vsl.xlsx', index = False)

# %% process life expectancy

# load in undiscoutned life expectancy data
life_exp_2022 = pd.read_excel(".../WPP2022_MORT_F05_1_LIFE_EXPECTANCY_BY_AGE_BOTH_SEXES.xlsx", sheet_name = "Estimates", skiprows = 16)
life_exp_2050 = pd.read_excel(".../WPP2022_MORT_F05_1_LIFE_EXPECTANCY_BY_AGE_BOTH_SEXES.xlsx", sheet_name = "Medium variant", skiprows = 16)

# create a function to prcoess the life expectancy data
def manage_life_exp(df):
    _df = df[["Region, subregion, country or area *", "Year", 0]].rename(columns={"Region, subregion, country or area *": "country", "Year":"year", 0: "LE_birth"})
    _df = _df[_df.country != "Micronesia"]
    _df = _df.replace(country_dict)
    _df = _df[_df.country.isin(countries)]
    _df = _df[(_df["year"] > 1999) & (_df["year"] < 2051)]
    _df.year = _df.year.astype(int)
    _df.life_exp = _df.LE_birth.astype(float)
    _df = _df.sort_values(["country", "year"])
    return _df

# process the life expectancy data
life_exp_hist = manage_life_exp(life_exp_2022)
life_exp_proj = manage_life_exp(life_exp_2050)
life_exps = pd.concat([life_exp_hist, life_exp_proj])
life_exps = life_exps.sort_values(["country", "year"])

# calculate the average age of the populations (we call this a_nought in the supplemental information)
life_exps["mid_age"] = (life_exps["LE_birth"]/2)
life_exps['mid_age'] = life_exps['mid_age'].apply(lambda x: round(x))
       
# load in the discounted life expectancy data                 
life_exp_dsct = pd.read_stata(".../discounted_LE_age_0_100.dta")
life_exp_dsct["country"] = life_exp_dsct["country"].replace(country_dict)
life_exp_dsct = life_exp_dsct[life_exp_dsct.country.isin(countries)]
life_exp_dsct = life_exp_dsct.rename(columns = {"LE": "LE_dsct"})

# only keep discounted life expectancy for a_nought
life_exp_df = life_exps.merge(life_exp_dsct, left_on = ["country", "year", "mid_age"], right_on = ["country", "year", "age"], how = "left")
life_exp_df = life_exp_df.drop(columns = "age")

# save the output
life_exp_df.to_excel('.../life_exp_vsl.xlsx', index = False)

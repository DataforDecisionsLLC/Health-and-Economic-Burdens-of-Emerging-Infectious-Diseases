# -*- coding: utf-8 -*-
"""
who_choice_processing.py

Description: Processes WHO-CHOICE data.

Created: 10 April 2024
Modified: 30 September 2024

Inputs:
    1. country_list.xlsx (created in country_list.py)
    2. country_names.xlsx
    3. who_choice_2010.xlsx
    4. whochoice_simple.xlsx (created in who_choice_macros.py)
    5. P_Data_Extract_From_World_Development_Indicators-GNI-GDP-Forex-Forex.xlsx
    6. country_year_population.xlsx (created in population.py)
    7. P_Data_Extract_From_World_Development_Indicators-GDP Deflator-2000_2022.xlsx
    8. P_Data_Extract_From_World_Development_Indicators_Metadata.xlsx
    9. RprtRateXchg_20010331_20231231.xlsx
    
Outputs:
    1. pcgdp_df.xlsx
    2. direct_costs.xlsx
    
Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the programs country_list.py,
       who_choice_macros.py, and population.py. Thus, those three programs must
       be run prior to running this program.
"""

# %% import libraries
import pandas as pd
import numpy as np
from scipy.stats import gmean

# %%  process WHO CHOICE data

# load in a full list of countries
country_list = pd.read_excel(".../country_list.xlsx")
countries = country_list.country.unique()

# load in a dictionary of country names
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

#load in inpatient and outpatient costs
inpatient = pd.read_excel(".../who_choice_2010.xlsx", sheet_name="bed_day_USD", usecols="A:D", skiprows=3)
outpatient = pd.read_excel(".../who_choice_2010.xlsx", sheet_name="outpatient_USD", usecols="A:B", skiprows=3)

#merge inpatient and outpatient costs to a single file
whochoice = inpatient.merge(outpatient, how = "outer", on = "Region/Country")
#rename columns to more usable values
whochoice = whochoice.rename(columns={"Health Centre (no beds)": "cost_per_day_mild",
                                      "Primary Hospital": "cost_per_day_severe",
                                      "Region/Country": "country"})

# costs nust be numeric
whochoice["cost_per_day_severe"] = whochoice["cost_per_day_severe"].replace("NA", "")
whochoice["cost_per_day_severe"] = pd.to_numeric(whochoice["cost_per_day_severe"], errors="coerce")
whochoice["cost_per_day_mild"] = whochoice["cost_per_day_mild"].replace("NA", "")
whochoice["cost_per_day_mild"] = pd.to_numeric(whochoice["cost_per_day_mild"], errors="coerce")

# remove unnecessary columns
whochoice = whochoice.drop(columns=["Secondary Hospital", "Tertiary Hospital"]).dropna()

#replace country names with authors' preferred versions
whochoice["country"] = whochoice["country"].replace(country_dict)

# add country data to WHO CHOICE data
whochoice = whochoice.merge(country_list, on = "country", how = "outer")

#load in foreign exchange rates data
macro = pd.read_excel(".../whochoice_simple.xlsx")
macro["country"] = macro["country"].replace(country_dict)

#merge WHO CHOICE data with foreign exchange rates data
whochoice = whochoice.merge(macro, on = "country", how = "left")

#convert WHO CHOiCE prices from 2010 LCUs to 2010 USDs.
whochoice["mild_2010_lcus"] = whochoice["cost_per_day_mild"]*whochoice["forex_2010"]
whochoice["severe_2010_lcus"] = whochoice["cost_per_day_severe"]*whochoice["forex_2010"]

# calculate the deflator conversion factor
whochoice["conversion_factor"] = whochoice["deflator_2022"]/whochoice["deflator_2010"]

# convert 2010 WHO choice costs in LCUs to 2019 values
whochoice["mild_2022_lcus"] = whochoice["mild_2010_lcus"]*whochoice["conversion_factor"]
whochoice["severe_2022_lcus"] = whochoice["severe_2010_lcus"]*whochoice["conversion_factor"]

# convert 2022 LCUs to 2022 using 2022 foreign exchange rates
whochoice["mild_2022_usd"] = whochoice["mild_2022_lcus"]/whochoice["forex_2022"]
whochoice["severe_2022_usd"] = whochoice["severe_2022_lcus"]/whochoice["forex_2022"]

# %% process gdp
# read in WDI GDP

# load in WDI data with GNI, GDP, and two types of foreign exchange rates
wdi = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-GNI-GDP-Forex-Forex.xlsx", skipfooter = 5)

# keep and perform minor processing of the GNI data
pcgni = wdi[wdi["Series Name"] == "GNI (current LCU)"]
pcgni = pcgni[["Country Name"] + [col for col in pcgni.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
pcgni["country"] = pcgni["country"].replace(country_dict)
pcgni.columns = pcgni.columns.str.split(' ').str[0]

# rename columns to indicate their source 
rename_dict = {col: 'wdi_pcgni_' + col for col in pcgni.columns[pcgni.columns.str.startswith('2')]}
pcgni = pcgni.rename(columns = rename_dict)
pcgni = pcgni.replace("..", np.nan)

# reshape the data
pcgni = pd.melt(pcgni, id_vars='country', value_vars=[col for col in pcgni.columns[pcgni.columns.str.startswith('wdi_pcgni_')]])
pcgni = pcgni.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"gni"})

# keep and perform minor processing of the GDP data
pcgdp = wdi[wdi["Series Name"] == "GDP (current LCU)"]
pcgdp = pcgdp[["Country Name"] + [col for col in pcgdp.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
pcgdp["country"] = pcgdp["country"].replace(country_dict)
pcgdp.columns = pcgdp.columns.str.split(' ').str[0]

# rename columns to indicate their source 
rename_dict = {col: 'wdi_pcgdp_' + col for col in pcgdp.columns[pcgdp.columns.str.startswith('2')]}
pcgdp = pcgdp.rename(columns = rename_dict)
pcgdp = pcgdp.replace("..", np.nan)

# reshape the data
pcgdp = pd.melt(pcgdp, id_vars='country', value_vars=[col for col in pcgdp.columns[pcgdp.columns.str.startswith('wdi_pcgdp_')]])
pcgdp = pcgdp.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"gdp"})

# rename the year columns
pcgni['year'] = pcgni['year'].map(lambda x: x.lstrip('wdi_pcgni_')).astype(int)
pcgdp['year'] = pcgdp['year'].map(lambda x: x.lstrip('wdi_pcgdp_')).astype(int)

# assign Cuba a value for GNI and GDP post 2020
pcgni.loc[(pcgni.country == "Cuba") & (pcgni.year > 2020), "gni"] = np.nan
pcgdp.loc[(pcgdp.country == "Cuba") & (pcgdp.year > 2020), "gdp"] = np.nan

# combine the GNI and GDP into a single data frame
gni_gdp = pcgni.merge(pcgdp, on = ["country", "year"], how = "outer")

# get a data frame of only complete data and calculate the country-specific ratio of GDP to GNI
complete_gni_gdp = gni_gdp.dropna()
complete_gni_gdp["ratio"] = complete_gni_gdp["gdp"]/complete_gni_gdp["gni"]
country_gni_gdp_ratios = complete_gni_gdp.groupby("country")["ratio"].mean().reset_index()

# get a data frame of missing GDP but non-missing GNI
nogni_gdp = gni_gdp[(gni_gdp.gdp.isna()) & (gni_gdp.gni.notna())]
nogni_gdp = nogni_gdp.merge(country_gni_gdp_ratios, on = "country", how = "left")

# estimate GDP in these countries by multipling GNI by the ratio calculate above
nogni_gdp["gdp"] = nogni_gdp["ratio"]*nogni_gdp["gni"]

# calculate the ratio at a yearly basis
year_gni_gdp_ratios = complete_gni_gdp.groupby("year")["ratio"].mean().reset_index()

# where there is no ratio for the country, multiply by the year-specific ratio
nogni_gdp2 = nogni_gdp[nogni_gdp.gdp.isna()].drop(columns = "ratio")
nogni_gdp2 = nogni_gdp2.merge(year_gni_gdp_ratios, on = "year", how = "left")
nogni_gdp2["gdp"] = nogni_gdp2["ratio"]*nogni_gdp2["gni"]

# combine the empirical and imputed GNI and GDP data
gni_gdp2 = pd.concat([nogni_gdp.dropna(), nogni_gdp2])
gni_gdp2 = gni_gdp2.merge(gni_gdp[["country", "year"]], on = ["country", "year"], how = "right")
gni_gdp = gni_gdp.set_index(["country", "year"]).fillna(gni_gdp2[["country", "year", "gni", "gdp"]].set_index(["country", "year"])).reset_index()

# drop GNI which we no longer need
pcgdp_df = gni_gdp.drop(columns = "gni")

# load in the processed population data
population_exps = pd.read_excel(".../country_year_population.xlsx")

# merge population data with GNI data and divide GDP by pop to get per capita GDP
pcgdp_df = pcgdp_df.merge(population_exps, on = ["country", "year"], how = "left")
pcgdp_df["pcgdp_lcu"] = pcgdp_df["gdp"]/pcgdp_df["tot_pop"]

# load in and do minor processing of the deflator data
deflator_raw = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-GDP Deflator-2000_2022.xlsx", skipfooter = 5)
deflator = deflator_raw[["Country Name", "Series Name"] + [col for col in deflator_raw.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
deflator = deflator[deflator["Series Name"] == "GDP deflator (base year varies by country)"].drop(columns = "Series Name")
deflator["country"] = deflator["country"].replace(country_dict)
deflator.columns = deflator.columns.str.split(' ').str[0]

# rename the columns to indicate the data source
rename_dict = {col: 'wdi_deflator_' + col for col in deflator.columns[deflator.columns.str.startswith('2')]}
deflator = deflator.rename(columns = rename_dict)
deflator = deflator.replace("..", np.nan)

# rename countries 
deflator = deflator[deflator.country.isin(countries)]

# reshape the data
deflator = pd.melt(deflator, id_vars='country', value_vars=[col for col in deflator.columns[deflator.columns.str.startswith('wdi_deflator_')]])
deflator = deflator.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"deflator"})

# rename columns and assign value for cuba
deflator['year'] = deflator['year'].map(lambda x: x.lstrip('wdi_deflator_')).astype(int)
deflator.loc[(deflator.country == "Cuba") & (deflator.year > 2020), "deflator"] = np.nan

# forward fill missing data
for c in deflator.country.unique():
    deflator.loc[deflator["country"] == c, "deflator"] = deflator.loc[deflator["country"] == c, "deflator"].fillna(
        deflator.loc[deflator["country"] == c, "deflator"].ffill())

# back fill missing data
for c in deflator.country.unique():
    deflator_2022 = deflator.loc[(deflator["country"] == c) & (deflator["year"] == 2022), "deflator"].values[0]
    deflator.loc[deflator["country"]==c, "inflation_ratio"] = deflator_2022/deflator.loc[deflator["country"]==c, "deflator"]

# merge gdp and deflator data
pcgdp_df = pcgdp_df.merge(deflator[["country", "year", "inflation_ratio"]], on = ["country", "year"], how = "left")

# create a function to calculate 2022 PCGDP in non-2022 years
def calc_2022_value(x, measure):
    return x[measure]*(x["inflation_ratio"])

# calculate PCGDP in 2022 LCUs for all years
pcgdp_df["pcgdp_lcu_2022"] = pcgdp_df.apply(lambda x: calc_2022_value(x, "pcgdp_lcu"), axis=1)

# calculate the growth rate  
pcgdp_df["growth_rate"] = np.nan
for c in pcgdp_df.country.unique():
    pcgdp_df.loc[pcgdp_df["country"] == c, 'growth_rate'] = (pcgdp_df.loc[pcgdp_df["country"] == c, 'pcgdp_lcu_2022'].pct_change(fill_method = "pad") + 1)
    
# calculate the average country-specific growth rate as the geometric mean
country_pcgdp_growth_rates = pcgdp_df.groupby("country")["growth_rate"].apply(lambda x: gmean(x, nan_policy = "omit")).reset_index()

# add the average growth rate data to the PCGNI data
pcgdp_df = pcgdp_df.drop(columns = "growth_rate").merge(country_pcgdp_growth_rates, on = "country", how = "left")

# assign growth rate for Taiwan
growth_rate = country_pcgdp_growth_rates[country_pcgdp_growth_rates.country.isin(countries)]
sk = growth_rate[growth_rate.country == "South Korea"]
taiwan = sk.replace({"South Korea": "Taiwan"})
growth_rate = pd.concat([growth_rate, taiwan]).sort_values(["country"])

# calculate missing PCGDP by forward filling, adjusting for growth 
for c in pcgdp_df.country.unique():
    for i in range(len(pcgdp_df.year.unique())):
        pcgdp_df.loc[pcgdp_df["country"] == c, "pcgdp_lcu_2022"] = pcgdp_df.loc[pcgdp_df["country"] == c, "pcgdp_lcu_2022"].fillna(
            pcgdp_df.loc[pcgdp_df["country"] == c, "pcgdp_lcu_2022"].ffill(limit=1).mul(
                pcgdp_df.loc[pcgdp_df["country"] == c, "growth_rate"].values[0]))

# calculate missing PCGDP by back filling, adjusting for growth     
for c in pcgdp_df.country.unique():
    for i in range(len(pcgdp_df.year.unique())):
        pcgdp_df.loc[pcgdp_df["country"] == c, "pcgdp_lcu_2022"] = pcgdp_df.loc[pcgdp_df["country"] == c, "pcgdp_lcu_2022"].fillna(
            pcgdp_df.loc[pcgdp_df["country"] == c, "pcgdp_lcu_2022"].bfill(limit=1).div(
                pcgdp_df.loc[pcgdp_df["country"] == c, "growth_rate"].values[0]))


# create a complete data frame of PCGDP in 2022 LCUs
pcgdp_final = pcgdp_df[["country", "year", "pcgdp_lcu_2022"]].sort_values(["country", "year"]).reset_index(drop = True)
pcgdp_final = pcgdp_final[pcgdp_final.country.isin(countries)]

# %% process foreign exchange rates

# load in the foreign exchange data and do minor processing
forex = wdi[wdi["Series Name"] == "DEC alternative conversion factor (LCU per US$)"]
forex = forex[["Country Name"] + [col for col in forex.columns if "[YR" in col]].rename(columns={"Country Name":"country"})
forex["country"] = forex["country"].replace(country_dict)
forex.columns = forex.columns.str.split(' ').str[0]

# rename columns
rename_dict = {col: 'wdi_forex_' + col for col in forex.columns[forex.columns.str.startswith('2')]}
forex = forex.rename(columns = rename_dict)
forex = forex.replace("..", np.nan)

# load in a df of currencies used in the data
country_currency = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators_Metadata.xlsx", sheet_name="Country - Metadata")
country_currency = country_currency[["Short Name", "Currency Unit", "Special Notes"]]
country_currency = country_currency.rename(columns={"Short Name": "country"}).replace(country_dict)
    
# create a list of countries using the US dollar.
usd_countries = country_currency[country_currency["Currency Unit"] == "U.S. dollar"]
usd_country_list = usd_countries.country.unique()

# set foreign exchange rate to 1 for countries using the USD.
for country in usd_country_list:
    forex.loc[forex["country"] == country, "wdi_forex_2000":"wdi_forex_2023"] = 1

# find the missing data in 2022 and 2021 and 2020
missing_forex = forex[(forex["wdi_forex_2020"].isna()) & (forex["wdi_forex_2021"].isna())& (forex["wdi_forex_2022"].isna())]

# find the currency for that data
missing_currencies = country_currency[country_currency.country.isin(missing_forex.country.unique())]

# assign foreign exchange rates based on the above information 
forex.loc[forex["country"] == "Channel Islands", "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Channel Islands", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"].isin(["Faeroe Islands", "Greenland"]), "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Denmark", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"] == "Liechtenstein", "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Switzerland", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"] == "Tuvalu", "wdi_forex_2000":"wdi_forex_2023"] = forex.loc[forex["country"] == "Australia", "wdi_forex_2000":"wdi_forex_2023"].values
forex.loc[forex["country"] == "Liberia", "wdi_forex_2000":"wdi_forex_2023"] = 1

#load in a treasury foreign exchange (forex) rate file.
forex_treas = pd.read_excel(".../RprtRateXchg_20010331_20231231.xlsx")

# make columns lowercase font
forex_treas.columns = forex_treas.columns.str.lower()
forex_treas[["country", "currency"]] = forex_treas["country - currency description"].str.rsplit("-", n=1, expand=True)
forex_treas.currency = forex_treas.currency.str.title()
forex_treas.country = forex_treas.country.str.title()

#again perform some renaming of countries.
forex_treas = forex_treas.replace(country_dict)

#only save pertinent dates
forex_treas["date"] = pd.to_datetime(forex_treas["record date"])
forex_treas = forex_treas[(forex_treas["date"] > "2007-12-31") & (forex_treas["date"] <= "2023-12-31")]
forex_treas['month'] = forex_treas['date'].dt.month
forex_treas = forex_treas[forex_treas["month"] == 12]
forex_treas['year'] = forex_treas['date'].dt.year

# use treasury exchange rates to fill in for missing existing exchange rates 
forex.loc[forex["country"] == "Venezuela", "wdi_forex_2022"] = forex_treas.loc[(forex_treas["country"] == "Venezuela") & (forex_treas["currency"] == "Bolivar Soberano") & (forex_treas["year"] == 2022), "exchange rate"].values[0]
forex.loc[forex["country"] == "Turkmenistan", "wdi_forex_2022"] = forex_treas.loc[(forex_treas["country"] == "Turkmenistan") & (forex_treas["currency"] == "New Manat") & (forex_treas["year"] == 2022), "exchange rate"].values[0]
forex.loc[forex["country"] == "Cuba", "wdi_forex_2022"] = forex_treas.loc[(forex_treas["country"] == "Cuba") & (forex_treas["currency"] == "Chavito") & (forex_treas["year"] == 2022), "exchange rate"].values[0]

# reshape the forex data
forex = pd.melt(forex, id_vars='country', value_vars=[col for col in forex.columns[forex.columns.str.startswith('wdi_forex_')]])
forex = forex.sort_values(["country", "variable"]).rename(columns = {"variable":"year", "value":"forex"})

# forward fill in missing exchange rates
for c in forex.country.unique():
    forex.loc[forex["country"] == c, "forex"] = forex.loc[forex["country"] == c, "forex"].fillna(
        forex.loc[forex["country"] == c, "forex"].ffill())

# only keep the 2022 forex
forex['year'] = forex['year'].map(lambda x: x.lstrip('wdi_forex_')).astype(int)
forex = forex[forex["year"] == 2022]

# merge PCGDP data with the forex data
pcgdp_final = pcgdp_final.merge(forex[["country", "forex"]], on = ["country"], how = "left")

# calculate PCGDP in 2022 USDs by dividing 2022 LCUs by the 2022 foreign exchange rate
pcgdp_final["pcgdp"] = pcgdp_final["pcgdp_lcu_2022"]/pcgdp_final["forex"]

# create a list of countries and fill in the year 2000 to 2023
country_list2 = country_list.loc[country_list.index.repeat(len(pcgdp_final.year.unique()))]
country_list2['year'] = np.tile(list(np.arange(2000, 2024)), len(country_list2)//len(list(np.arange(2000, 2024))))

# add the country information and year information to the PCGDP data
pcgdp_final = pcgdp_final.merge(country_list2[["country", "year", "who_region", "wb_inc_group"]], on = ["country", "year"], how = "outer")

# create a variable for the WHO region-World Bank income group
pcgdp_final["who_income"] = pcgdp_final[["who_region","wb_inc_group"]].agg('-'.join, axis=1)

# fill in missing data with the group median
for i in pcgdp_final.who_income.unique():
    for t in pcgdp_final.year.unique():
        pcgdp_final.loc[(pcgdp_final["who_income"] == i) & (pcgdp_final["year"] == t), "pcgdp"] = pcgdp_final['pcgdp'].fillna((pcgdp_final.loc[(pcgdp_final["who_income"] == i) & (pcgdp_final["year"] == t), 'pcgdp'].median()))

# fill in missing data with the group median
for i in pcgdp_final.wb_inc_group.unique():
    for t in pcgdp_final.year.unique():
        pcgdp_final.loc[(pcgdp_final["wb_inc_group"] == i) & (pcgdp_final["year"] == t), "pcgdp"] = pcgdp_final['pcgdp'].fillna((pcgdp_final.loc[(pcgdp_final["wb_inc_group"] == i) & (pcgdp_final["year"] == t), 'pcgdp'].median()))

# save the PCGDP data
pcgdp_final[["country", "year", "pcgdp"]].to_excel(".../pcgdp_df.xlsx", index = False)

# South Sudan's data is unreliable. We therefore use Sudan as our best proxy.
for t in pcgdp_final.year.unique():
    pcgdp_final.loc[(pcgdp_final["country"] == "South Sudan") & (pcgdp_final["year"] == t), "pcgdp"] = pcgdp_final.loc[(pcgdp_final["country"] == "Sudan") & (pcgdp_final["year"] == t), "pcgdp"].values[0]

# only keep the data in 2022
pcgdp_whochoice = pcgdp_final[["country", "year", "pcgdp"]]
pcgdp_whochoice = pcgdp_whochoice[pcgdp_whochoice.year == 2022]

# %% extrapolate for countries without WHO CHOICE data

# add GDP data to WHO choice data
whochoice = whochoice.merge(pcgdp_whochoice[["country", "pcgdp"]],
                            on = "country", how = "left")

# create two empty columns to be used for extrapolating direct costs
whochoice["match"] = np.nan
whochoice["ratio"] = np.nan

# create an income-geography indicator variable
whochoice['who_income'] = whochoice[['who_region', 'wb_inc_group']].astype(str).apply(lambda x: '_'.join(x), axis=1)

# create a data frame that only contains complete data 
whochoice_complete = whochoice.dropna(subset=["mild_2022_usd", "severe_2022_usd",
                                              "pcgdp"], how = 'any').reset_index(drop = True)

# create a function that maps direct costs 
def map_direct_df(country):
    """
    Map direct costs to a country without direct cost data.

    Parameters
    ----------
    country : string
        A string containing the name of the country of interest.

    Returns
    -------
    whochoice : data frame
        A data frame that contains direct cost data for all countries.

    """
    # find the WHO Region - World Bank Income Group of the country
    whoincome = whochoice.loc[whochoice["country"] == country, "who_income"].values[0]
    # create a data frame of countries in that region-income group.
    whoinc_df = whochoice_complete[whochoice_complete["who_income"] == whoincome].reset_index(drop = True)
    # create a data frame that only has the country of interest
    country_df = whochoice[whochoice["country"] == country]
    # if the country doesn't have WHO CHOICE data
    if np.isnan(country_df.loc[:, "severe_2022_usd"].values[0]):
        # extract the country's per capita GDP
        pcgdp = country_df["pcgdp"].values[0]
        # if the country also doesn't have per capita GDP, just skip it
        if np.isnan(pcgdp):
            pass
        # but if it does have pcgdp
        else:
            # get an array of PCGDP of countries in the same region-income group.
            whoinc_pcgdp = np.array(whoinc_df.loc[:, "pcgdp"])
            # calculate the difference between the country of interest's pcgdp and 
            # the region-income group countries' pcgdp
            pcgdp_diff = np.absolute(whoinc_pcgdp - pcgdp)
            # find the value where the difference is the smallest (i.e., closest pcgdp to the country of interest)
            index_val = pcgdp_diff.argmin()
            # get the name of the country that has the most similar pcgdp
            mapping_country = whoinc_df.loc[index_val, "country"]
            # get the pcgdp value of that country
            pcgdp_mapping = whoinc_df.loc[whoinc_df["country"] == mapping_country, "pcgdp"].values[0]
            # take the ratio of the pcgdp of the mapping country and the country of interest
            ratio = pcgdp/pcgdp_mapping
            # note which country was used to map in the direct costs data
            whochoice.loc[whochoice["country"] == country, "match"] = mapping_country
            # add the pcgdp ratio to the data
            whochoice.loc[whochoice["country"] == country, "ratio"] = ratio
            # for mild, severe, and critical direct costs, assign them to be the value of 
            # mapping country, scaled for the ratio of pcgdp
            whochoice.loc[whochoice["country"] == country, "mild_2022_usd": "severe_2022_usd"] = (
                whochoice.loc[whochoice["country"] == mapping_country,
                              "mild_2022_usd": "severe_2022_usd"].values)*ratio
    # but if the country does have WHO CHOICE data
    else:
        # do nothing
        pass
    # return the direct costs data
    return whochoice

# get a list of countries to perform extrapolations for
whochoice_mapping_countries = list(whochoice.country.unique())
whochoice_mapping_countries.remove("North Korea")

# for all the countries in our data, perform the utility mapping
for c in whochoice_mapping_countries:
    whochoice = map_direct_df(c)    

# assign North Korea the values of low income countries
whochoice.loc[(whochoice["country"] == "North Korea"), "mild_2022_usd"] = whochoice['mild_2022_usd'].fillna((whochoice.loc[(whochoice["wb_inc_group"] == "Low income"), 'mild_2022_usd'].median()))
whochoice.loc[(whochoice["country"] == "North Korea"), "severe_2022_usd"] = whochoice['severe_2022_usd'].fillna((whochoice.loc[(whochoice["wb_inc_group"] == "Low income"), 'severe_2022_usd'].median()))

# simplify the data to only have the country name, region-income group, and direct costs in 2022USD
direct_df = whochoice[["country", "mild_2022_usd","severe_2022_usd"]]

# save the output
direct_df.to_excel(".../direct_costs.xlsx", index = False)

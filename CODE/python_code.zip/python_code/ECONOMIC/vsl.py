# -*- coding: utf-8 -*-
"""
vsl.py

Description: Performs the VSL analysis.

Created: 11 April 2024
Modified: 30 September 2024

Inputs:
    1. country_list.xlsx (created in country_list.py)
    2. country_names.xlsx
    3. SeriesReport-20240412093032_7af632.xlsx
    4. SeriesReport-20240412093715_dcffc6.xlsx
    5. pcgni_vsl.xlsx (created in vsl_macros.py)
    6. life_exp_vsl.xlsx (created in vsl_macros.py)

Outputs:
    1. vsl_df.xlsx
    2. equity_df.xlsx

Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the programs country_list.py
       and vsl_macros.py. Thus, those two programs must be run prior to running
       this program.    
"""

# %% load in libraries
import pandas as pd
import numpy as np
import math

# %% process data 

#load in a list of the countries
country_list = pd.read_excel(".../country_list.xlsx")
countries = country_list["country"].unique()

#loading a dictionary that is used to rename countries
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

# rename countries and assign Venezuela an income group
country_list = country_list.replace(country_dict)
country_list.loc[country_list.country == "Venezuela", "wb_inc_group"] = "Upper middle income"

# %% process US VSL

# 2020 estimate of US VSL from the US HHS
vsl_2020 = 11410084.92

# load in US inflation data recommended by US HHS 
inflation_us = pd.read_excel(".../SeriesReport-20240412093032_7af632.xlsx", skiprows=11)
inflation_index_2020 = inflation_us.loc[(inflation_us["Year"] == 2020), "Annual"].values[0]
inflation_index_2022 = inflation_us.loc[(inflation_us["Year"] == 2022), "Annual"].values[0]
inflation_adjustment = inflation_index_2022/inflation_index_2020

# load in US income data recommended by US HHS
real_income_us = pd.read_excel(".../SeriesReport-20240412093715_dcffc6.xlsx", skiprows=19)
real_income_2020 = real_income_us.loc[(real_income_us["Year"] == 2020), "Annual"].values[0]
real_income_2022 = real_income_us.loc[(real_income_us["Year"] == 2022), "Annual"].values[0]
hist_change_real_income = real_income_2022/real_income_2020

# set an elasticity for the US (equal to 1)
elasticity_US = 1

# calculate US VSL in 2022 using formula from US HHS guidelines
vsl_2022 = vsl_2020*inflation_adjustment*(hist_change_real_income)**elasticity_US

# %% process foreign VSLs

# load in processed PCGNI data
pcgni = pd.read_excel(".../pcgni_vsl.xlsx")
country_list = country_list.merge(pcgni, on = "country", how = "right")

# create a dictionary of elasticities based on countries' incomes
elasticity_dict = {"Low income": 1.5, "Middle income": 1.2, "High income": 1}

# for countries that are upper or lower middle income, just simplify to middle income 
country_list.loc[(country_list["wb_inc_group"] == "Upper middle income") | (country_list["wb_inc_group"] == "Lower middle income"), "wb_inc_group"] = "Middle income"

# create an empty variable for elasticities
country_list["elasticity"] = np.nan

# and assign countries an elasticity based on their income group
for key,value in elasticity_dict.items():
    country_list.loc[country_list["wb_inc_group"] == key, "elasticity"] = value
    
# create a function to calculate country-specific VSL in 2022 based on US VSL in 2022
def vsl_target(x, vsl_base, income_target, income_base, elasticity):
    return vsl_base*(x[income_target]/income_base)**x[elasticity]
    
# get the US PCGNI in 2022
income_us = country_list.loc[(country_list["country"] == "United States") & (country_list["year"] == 2022), "pcgni"].values[0]

# calculate country-specific VSL in 2022 using the above formula
country_list.loc[country_list["year"] == 2022, "vsl"] = country_list.apply(lambda x: vsl_target(x, vsl_2022, 'pcgni', income_us, 'elasticity'), axis=1)

# load in the life expectancy data
life_exp = pd.read_excel(".../life_exp_vsl.xlsx")
country_list = country_list.merge(life_exp[["country", "year", "LE_dsct"]], on = ["country", "year"], how = "outer")

# create a new elasticity variable for intra-country calculations
country_list["elasticity_internal"] = 1

# get the country-specific vsl and income in 2022 and use the above formula to calculate VSL in non-2022 years
for c in country_list.country.unique():
    vsl_2022 = country_list.loc[(country_list["country"] == c) & (country_list["year"] == 2022), "vsl"].values[0]
    income_2022 = country_list.loc[(country_list["country"] == c) & (country_list["year"] == 2022), "pcgni"].values[0]
    for t in country_list.year.unique():
        country_list.loc[(country_list["country"] == c) & (country_list["year"] == t), "vsl"] = country_list.apply(lambda x: vsl_target(x, vsl_2022, 'pcgni', income_2022, "elasticity_internal"), axis=1)

# create a function to calculate VSLY from VSL
def vsly_c(x, vsl, life_exp):
    return x[vsl]/(x[life_exp])

# use the above formula to calculate VSLY
country_list["vsly"] = country_list.apply(lambda x: vsly_c(x, "vsl", "LE_dsct"), axis=1)

# only keep the relevant VSL and VSLY data
vsl_df = country_list[["country", "year", "vsl", "vsly"]]
vsl_df = vsl_df[vsl_df.year < 2023]

# and save the ouptut
vsl_df.to_excel(".../vsl_df.xlsx", index = False)

# create a data frame to estimate equity weights
equity_df = country_list[["country", "year", "pcgni"]]
equity_df = equity_df[equity_df.year < 2023]

# the constant numerator from which equity weights are calculated is the US PCGNI 
numerator = equity_df.loc[(equity_df["country"] == "United States") & (equity_df["year"] == 2021), "pcgni"].values[0]

# create a function to calculate equity weights for each country
def equity_weight(x, pcgni):
    return numerator/x[pcgni]

# calculate equity weights 
equity_df["equity_weight"] = equity_df.apply(lambda x: equity_weight(x, "pcgni"), axis = 1)

# and save the output
equity_df.to_excel(".../equity_df.xlsx", index = False)

# -*- coding: utf-8 -*-
"""
who_choice_macros.py

Description: Creates all the variables needed to perform the WHO CHOICE analysis.

Created: 10 April 2024
Modified: 30 September 2024

Inputs:
    1. country_list.xlsx (created in country_list.py)
    2. country_names.xlsx
    3. who_choice_2010.xlsx
    4. P_Data_Extract_From_World_Development_Indicators.xlsx
    5. P_Data_Extract_From_World_Development_Indicators-forex.xlsx
    6. P_Data_Extract_From_Global_Economic_Monitor_(GEM).xlsx
    7. RprtRateXchg_20010331_20231231.xlsx
    8. P_Data_Extract_From_World_Development_Indicators-GDP deflator.xlsx
    9. WEOOct2023all.xlsx
    
Outputs:
    1. whochoice_simple.xlsx
    
Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the programs country_list.py. 
       Thus, country_list.py must be run prior to running this program.
"""

# %% load in libraries
import pandas as pd
import numpy as np

# %% load in and process raw WHO CHOICE data

#load in a list of the countries
countries = pd.read_excel(".../country_list.xlsx")

#loading a dictionary that is used to rename countries
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

#load in inpatient and outpatient costs
inpatient = pd.read_excel(".../who_choice_2010.xlsx", sheet_name="bed_day_USD", usecols="A:D", skiprows=3)
outpatient = pd.read_excel(".../who_choice_2010.xlsx", sheet_name="outpatient_USD", usecols="A:B", skiprows=3)

#merge inpatient and outpatient costs to a single file
whochoice = inpatient.merge(outpatient, how = "outer", on = "Region/Country")
#rename columns to more usable values
whochoice = whochoice.rename(columns={"Health Centre (no beds)": "cost_per_day_mild",
                                      "Primary Hospital": "cost_per_day_severe",
                                      "Region/Country": "country"})

#replace country names with authors' preferred versions
whochoice["country"] = whochoice["country"].replace(country_dict)

# drop unnecessary data
whochoice = whochoice.drop(columns=["Secondary Hospital", "Tertiary Hospital"]).dropna()

# add country data to the who choic edata
whochoice_macros = whochoice[["country"]].merge(countries, on = "country", how = "outer")

#load in one of the WDI sources for foreign exchange (forex) rates.
forex_wdi = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators.xlsx", skipfooter=5)

# rename countries and columns
forex_wdi = forex_wdi.replace(country_dict)
forex_wdi = forex_wdi.rename(columns = {"Country Name": "country"})
forex_wdi = forex_wdi[["country"] + [col for col in forex_wdi.columns if "[YR" in col]]
forex_wdi.columns = forex_wdi.columns.str.split(' ').str[0]
rename_dict = {col: 'wdi_forex_' + col for col in forex_wdi.columns[forex_wdi.columns.str.startswith('2')]}
forex_wdi = forex_wdi.rename(columns = rename_dict)
forex_wdi = forex_wdi.replace("..", np.nan)

#only keep countries that are in our study
forex_wdi_project = forex_wdi[forex_wdi["country"].isin(whochoice_macros.country.unique())]
forex_wdi_project = forex_wdi_project[["country", "wdi_forex_2009", "wdi_forex_2010", "wdi_forex_2011", "wdi_forex_2020", "wdi_forex_2021", "wdi_forex_2022"]]

# load in another source of WDI foreign exchange rates
old_wdi = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-forex.xlsx", skipfooter=5)

# rename countries and columns
old_wdi = old_wdi.replace(country_dict)
old_wdi = old_wdi.rename(columns = {"Country Name": "country"})
old_wdi = old_wdi[["country"] + [col for col in old_wdi.columns if "[YR" in col]]
old_wdi.columns = old_wdi.columns.str.split(' ').str[0]
rename_dict = {col: 'wdi_forex_' + col for col in old_wdi.columns[old_wdi.columns.str.startswith('2')]}
old_wdi = old_wdi.rename(columns = rename_dict)
old_wdi = old_wdi.replace("..", np.nan)

#only keep countries that are in our study
old_wdi_project = old_wdi[old_wdi["country"].isin(whochoice_macros.country.unique())]
old_wdi_project = old_wdi_project[["country", "wdi_forex_2009", "wdi_forex_2010", "wdi_forex_2011", "wdi_forex_2020", "wdi_forex_2021", "wdi_forex_2022"]]

# find 2010 foreign exchange rates for countries that have missing data in our primary forex source
wdi_2010_missing = forex_wdi_project.loc[forex_wdi_project["wdi_forex_2010"].isna(), "country"].unique()
old_2010_notmissing = old_wdi_project.loc[(old_wdi_project["wdi_forex_2010"].notna()) & (old_wdi_project.country.isin(wdi_2010_missing))]
old_2010_notmissing = old_2010_notmissing.merge(forex_wdi_project[["country"]], on = "country", how = "right")
forex_wdi_project = forex_wdi_project.set_index("country").fillna(old_2010_notmissing[["country", "wdi_forex_2010"]].set_index("country")).reset_index()

# find 2022 foreign exchange rates for countries that have missing data in our primary forex source
wdi_2022_missing = forex_wdi_project.loc[forex_wdi_project["wdi_forex_2022"].isna(), "country"].unique()
old_2022_notmissing = old_wdi_project.loc[(old_wdi_project["wdi_forex_2022"].notna()) & (old_wdi_project.country.isin(wdi_2022_missing))]
old_2022_notmissing = old_2022_notmissing.merge(forex_wdi_project[["country"]], on = "country", how = "right")
forex_wdi_project = forex_wdi_project.set_index("country").fillna(old_2022_notmissing[["country", "wdi_forex_2022"]].set_index("country")).reset_index()
forex_wdi_project.loc[forex_wdi_project["country"].isin(["American Samoa","Northern Mariana Islands", "United States Virgin Islands", "British Virgin Islands"]), "wdi_forex_2010"] = 1
forex_wdi_project.loc[forex_wdi_project["country"].isin(["American Samoa","Northern Mariana Islands", "United States Virgin Islands", "British Virgin Islands"]), "wdi_forex_2022"] = 1

#load in GEM foreign exchange rate file
forex_gem = pd.read_excel(".../P_Data_Extract_From_Global_Economic_Monitor_(GEM).xlsx")

# rename countries and columns
forex_gem = forex_gem.rename(columns = {"Country": "country"})
forex_gem = forex_gem[["country"] + [col for col in forex_gem.columns if "[" in col]]
forex_gem.columns = forex_gem.columns.str.split(' ').str[0]
rename_dict = {col: 'gem_forex_' + col for col in forex_gem.columns[forex_gem.columns.str.startswith('2')]}
forex_gem = forex_gem.rename(columns = rename_dict)
forex_gem = forex_gem.replace("..", np.nan)
forex_gem = forex_gem.replace(country_dict)

#only keep countries in our study
forex_gem_project = forex_gem[forex_gem["country"].isin(whochoice_macros.country.unique())]
forex_gem_project = forex_gem_project[["country", "gem_forex_2009", "gem_forex_2010", "gem_forex_2011", "gem_forex_2020", "gem_forex_2021", "gem_forex_2022"]]

forex_project = forex_wdi_project.merge(forex_gem_project, on ="country", how = "outer")

#load in a treasury foreign exchange rate file.
forex_treas = pd.read_excel(".../RprtRateXchg_20010331_20231231.xlsx")

# make columns lowercase font
forex_treas.columns = forex_treas.columns.str.lower()
forex_treas[["country", "currency"]] = forex_treas["country - currency description"].str.rsplit("-", n=1, expand=True)
forex_treas.currency = forex_treas.currency.str.title()
forex_treas.country = forex_treas.country.str.title()

#again perform some renaming of countries.
forex_treas = forex_treas.replace(country_dict)

#only save pertinent dates
forex_treas["date"] = pd.to_datetime(forex_treas["record date"])
forex_treas = forex_treas[(forex_treas["date"] > "2007-12-31") & (forex_treas["date"] <= "2023-12-31")]
forex_treas['month'] = forex_treas['date'].dt.month
forex_treas = forex_treas[forex_treas["month"] == 12]
forex_treas['year'] = forex_treas['date'].dt.year

#again only keep countries that are in our study
forex_treas_project = forex_treas[forex_treas["country"].isin(forex_project.country.unique())]
forex_treas_project = forex_treas_project.drop_duplicates(subset = ["country", "currency","date"], keep = False)
forex_treas_project = forex_treas_project.pivot(index = ['country', 'currency'], columns='year',
                                      values='exchange rate')

forex_treas_project.columns = ["treas_forex_" + col for col in forex_treas_project.columns.astype(str)]
forex_treas_project = forex_treas_project.reset_index(drop = False)

# establish two empty columns to fill
forex_project["treas_forex_2010"] = np.nan
forex_project["treas_forex_2022"] = np.nan

# fill in those columns for Venezuela, Cuba, Turkmenistan, and Syria
forex_project.loc[forex_project["country"]=="Venezuela", "treas_forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Venezuela") & (forex_treas_project["currency"] == "Soberano (Old)"), "treas_forex_2010"].values[0]
forex_project.loc[forex_project["country"]=="Venezuela", "treas_forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Venezuela") & (forex_treas_project["currency"] == "Fuerte (Old)"), "treas_forex_2022"].values[0]*100000

forex_project.loc[forex_project["country"]=="Cuba", "treas_forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Cuba") & (forex_treas_project["currency"] == "Chavito"), "treas_forex_2010"].values[0]
forex_project.loc[forex_project["country"]=="Cuba", "treas_forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Cuba") & (forex_treas_project["currency"] == "Chavito"), "treas_forex_2022"].values[0]

forex_project.loc[forex_project["country"]=="Turkmenistan", "treas_forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Turkmenistan") & (forex_treas_project["currency"] == "New Manat"), "treas_forex_2010"].values[0]
forex_project.loc[forex_project["country"]=="Turkmenistan", "treas_forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Turkmenistan") & (forex_treas_project["currency"] == "New Manat"), "treas_forex_2022"].values[0]

forex_project.loc[forex_project["country"]=="Syria", "treas_forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Syria") & (forex_treas_project["currency"] == "Pound"), "treas_forex_2010"].values[0]
forex_project.loc[forex_project["country"]=="Syria", "treas_forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Syria") & (forex_treas_project["currency"] == "Pound"), "treas_forex_2021"].values[0]

# create a simplified data frame
forex_project_simple = pd.DataFrame({"forex_2010": np.nan, "forex_2022": np.nan}, index = forex_project.country.unique())

# fill it in with WDI data first
forex_project_simple = forex_project_simple.fillna(forex_wdi_project[["country", "wdi_forex_2010", "wdi_forex_2022"]].set_index("country").rename(columns={"wdi_forex_2010":"forex_2010", "wdi_forex_2022":"forex_2022"}))
# fill it in with GEM data second
forex_project_simple = forex_project_simple.fillna(forex_gem_project[["country", "gem_forex_2010", "gem_forex_2022"]].set_index("country").rename(columns={"gem_forex_2010":"forex_2010", "gem_forex_2022":"forex_2022"}))

"""
in the following 40 lines we fill in for specific missing instances
"""

forex_2010_missing = forex_project_simple.loc[forex_project_simple["forex_2010"].isna()].index
wdi_2011_notmissing = forex_wdi_project.loc[(forex_wdi_project["wdi_forex_2011"].notna()) & (forex_wdi_project.country.isin(forex_2010_missing))]
gem_2011_notmissing = forex_gem_project.loc[(forex_gem_project["gem_forex_2011"].notna()) & (forex_gem_project.country.isin(forex_2010_missing))]
wdi_2009_notmissing = forex_wdi_project.loc[(forex_wdi_project["wdi_forex_2009"].notna()) & (forex_wdi_project.country.isin(forex_2010_missing))]
gem_2009_notmissing = forex_gem_project.loc[(forex_gem_project["gem_forex_2009"].notna()) & (forex_gem_project.country.isin(forex_2010_missing))]

forex_project_simple = forex_project_simple.fillna(wdi_2011_notmissing[["country", "wdi_forex_2011"]].set_index("country").rename(columns={"wdi_forex_2011":"forex_2010"}))

forex_2022_missing = forex_project_simple.loc[forex_project_simple["forex_2022"].isna()].index
wdi_2021_notmissing = forex_wdi_project.loc[(forex_wdi_project["wdi_forex_2021"].notna()) & (forex_wdi_project.country.isin(forex_2022_missing))]
gem_2021_notmissing = forex_gem_project.loc[(forex_gem_project["gem_forex_2021"].notna()) & (forex_gem_project.country.isin(forex_2022_missing))]
wdi_2020_notmissing = forex_wdi_project.loc[(forex_wdi_project["wdi_forex_2020"].notna()) & (forex_wdi_project.country.isin(forex_2022_missing))]
gem_2020_notmissing = forex_gem_project.loc[(forex_gem_project["gem_forex_2020"].notna()) & (forex_gem_project.country.isin(forex_2022_missing))]

forex_project_simple = forex_project_simple.fillna(wdi_2021_notmissing[["country", "wdi_forex_2021"]].set_index("country").rename(columns={"wdi_forex_2021":"forex_2022"}))
forex_project_simple = forex_project_simple.fillna(gem_2021_notmissing[["country", "gem_forex_2021"]].set_index("country").rename(columns={"gem_forex_2021":"forex_2022"}))

forex_project_simple = forex_project_simple.fillna(wdi_2020_notmissing[["country", "wdi_forex_2020"]].set_index("country").rename(columns={"wdi_forex_2020":"forex_2022"}))
forex_project_simple = forex_project_simple.fillna(gem_2020_notmissing[["country", "gem_forex_2020"]].set_index("country").rename(columns={"gem_forex_2020":"forex_2022"}))

forex_project_simple = forex_project_simple.reset_index().rename(columns={"index":"country"})

forex_project_simple.loc[forex_project_simple["country"].isin(["Latvia", "Lithuania", "Estonia", "French Saint Martin"]), "forex_2010"] = forex_project_simple.loc[forex_project_simple["country"]=="Belgium", "forex_2010"].values[0]
forex_project_simple.loc[forex_project_simple["country"].isin(["French Saint Martin"]), "forex_2022"] = forex_project_simple.loc[forex_project_simple["country"]=="Belgium", "forex_2022"].values[0]

forex_project_simple.loc[forex_project_simple["country"]=="Venezuela", "forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Venezuela") & (forex_treas_project["currency"] == "Soberano (Old)"), "treas_forex_2010"].values[0]
forex_project_simple.loc[forex_project_simple["country"]=="Venezuela", "forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Venezuela") & (forex_treas_project["currency"] == "Fuerte (Old)"), "treas_forex_2022"].values[0]*1000000

forex_project_simple.loc[forex_project_simple["country"]=="Cuba", "forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Cuba") & (forex_treas_project["currency"] == "Chavito"), "treas_forex_2010"].values[0]
forex_project_simple.loc[forex_project_simple["country"]=="Cuba", "forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Cuba") & (forex_treas_project["currency"] == "Chavito"), "treas_forex_2022"].values[0]

forex_project_simple.loc[forex_project_simple["country"]=="Turkmenistan", "forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Turkmenistan") & (forex_treas_project["currency"] == "New Manat"), "treas_forex_2010"].values[0]
forex_project_simple.loc[forex_project_simple["country"]=="Turkmenistan", "forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Turkmenistan") & (forex_treas_project["currency"] == "New Manat"), "treas_forex_2022"].values[0]

forex_project_simple.loc[forex_project_simple["country"]=="Syria", "forex_2010"] = forex_treas_project.loc[(forex_treas_project["country"] == "Syria") & (forex_treas_project["currency"] == "Pound"), "treas_forex_2010"].values[0]
forex_project_simple.loc[forex_project_simple["country"]=="Syria", "forex_2022"] = forex_treas_project.loc[(forex_treas_project["country"] == "Syria") & (forex_treas_project["currency"] == "Pound"), "treas_forex_2021"].values[0]

forex_project_simple.loc[forex_project_simple["country"] == "Palestine", ["forex_2010", "forex_2022"]] = forex_project_simple.loc[forex_project_simple["country"] == "Israel", ["forex_2010", "forex_2022"]].values

#%% prcoess GDP deflators

#load in GDP wdi_deflators
wdi_deflators = pd.read_excel(".../P_Data_Extract_From_World_Development_Indicators-GDP deflator.xlsx")
wdi_deflators = wdi_deflators[wdi_deflators["Series Name"] == "GDP deflator (base year varies by country)"].rename(
    columns = {"Country Name": "country"})

#keep country names and year-specific deflator values. 
wdi_deflators = wdi_deflators[["country"] + [col for col in wdi_deflators.columns if "[YR" in col]]
wdi_deflators.columns = wdi_deflators.columns.str.split(' ').str[0]
wdi_deflators = wdi_deflators.replace("..", np.nan)

#replace country names with author preferred versions.
wdi_deflators = wdi_deflators.replace(country_dict)

# find the countries who don't have deflator data for 2010 or 2019.
countries_needed = wdi_deflators.loc[(wdi_deflators["2010"].isna()) | (wdi_deflators["2022"].isna()), 'country'].values

# read in the World Economic Outlook data from the end of 2022.
imf_deflators = pd.read_excel(".../WEOOct2023all.xlsx")
# keep the rows that contain GDP wdi_deflators
imf_deflators = imf_deflators[imf_deflators["Subject Descriptor"] =="Gross domestic product, deflator"]
# Rename Taiwan to author-preferred name
imf_deflators = imf_deflators.replace(country_dict)
# retain the entries that pertain to countries without a full set of wdi_deflators from WDI
imf_deflators = imf_deflators[imf_deflators["Country"].isin(countries_needed)]
# simplify the data to contain country name and select years of wdi_deflators
imf_deflators = imf_deflators[["Country", 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015,2016, 2017,2018, 2019,2020,2021,2022]].rename(
    columns = {"Country": "country"})
imf_deflators.columns = imf_deflators.columns.astype(str)

# fill in missing WDI data with IMF data
wdi_deflators = wdi_deflators.set_index("country").fillna(imf_deflators[["country", "2010", "2022"]].set_index("country")).reset_index()

# fill in missing data
wdi_deflators.loc[wdi_deflators["2010"].isna() & wdi_deflators["2011"].notna(), "2010"] = wdi_deflators.loc[wdi_deflators["2010"].isna() & wdi_deflators["2011"].notna(), "2011"]
wdi_deflators.loc[wdi_deflators["2022"].isna() & wdi_deflators["2021"].notna(), "2022"] = wdi_deflators.loc[wdi_deflators["2022"].isna() & wdi_deflators["2021"].notna(), "2021"]
wdi_deflators.loc[wdi_deflators["2010"].isna() & wdi_deflators["2009"].notna(), "2010"] = wdi_deflators.loc[wdi_deflators["2010"].isna() & wdi_deflators["2009"].notna(), "2009"]
wdi_deflators.loc[wdi_deflators["2022"].isna() & wdi_deflators["2020"].notna(), "2022"] = wdi_deflators.loc[wdi_deflators["2022"].isna() & wdi_deflators["2020"].notna(), "2020"]

# fill in data for Eritrea
wdi_deflators.loc[(wdi_deflators["country"] == "Eritrea"), "2022"] = imf_deflators.loc[imf_deflators["country"] == "Eritrea", "2019"].values[0]

# simplify the data to only contain the country and 2010 and 2019 wdi_deflators, and rename the columns
wdi_deflators = wdi_deflators[["country", "2010", "2022"]].rename(columns = {"2010": "deflator_2010",
                                                                     "2022": "deflator_2022"})

# create a simple deflator file
deflators_simple = wdi_deflators.merge(forex_project_simple[["country"]], on = "country", how = 'right')

deflators_project = wdi_deflators.merge(imf_deflators, on = "country", how = "outer")

whochoice_simple = forex_project_simple.merge(deflators_simple, on = "country", how = "outer")

whochoice_simple.to_excel('.../whochoice_simple.xlsx', index = False)

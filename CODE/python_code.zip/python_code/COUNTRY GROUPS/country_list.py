# -*- coding: utf-8 -*-
"""
county_list.py

Description: Creates a full list of countries in the analysis.

Created: 28 March 2024
Modified: 30 September 2024

Inputs:
    1. country_names.xlsx
    2. master_study_country_list.xlsx (created in make_master_study_country_list.do)
    3. UNSD-Methodology.xlsx
    4. who-regions.csv
    5. world_bank_classification.xlsx
    
Outputs:
    1. country_list.xlsx

Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the program make_master_study_country_list.do. 
       Thus, make_master_study_country_list.do must be run prior to running this program.
"""

# %% import libraries
import pandas as pd
import numpy as np

# %% load in general IHME data
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

#load in and do minor processing of a list of the study's countries
country_list = pd.read_excel(".../master_study_country_list.xlsx")
country_list = country_list[country_list.country != "Saint Martin / Sint Maarten"]
    
countries = pd.DataFrame(country_list["country"].unique())
countries.columns = ["country"]

# load in and do minor processing of a list of the UN regions for each country
un_regions = pd.read_excel(".../UNSD-Methodology.xlsx")
un_regions = un_regions.rename(columns = {"Country or Area": "country", "Sub-region Name": "un_subregion"})
un_regions = un_regions.replace(country_dict)

# assign a UN region to countries without one in the previous dataset
countries = countries.merge(un_regions[["country", "un_subregion"]], on = "country", how = "left")
countries.loc[countries["country"].isin(["China, Hong Kong SAR", "China, Macao SAR"]), "un_subregion"] = "Eastern Asia"
countries.loc[countries["country"].isin(["Taiwan", "China, Macao SAR"]), "un_subregion"] = "Eastern Asia"
countries.loc[countries["country"] == "French Saint Martin", "un_subregion"] = "Latin America and the Caribbean"
countries.loc[countries["country"] == "Saint Martin / Sint Maarten", "un_subregion"] = "Latin America and the Caribbean"
countries.loc[countries["country"] == "Kosovo", "un_subregion"] = "Southern Europe"
countries.loc[countries["country"] == "Palestine", "un_subregion"] = "Western Asia"

# load in and do minor processing of a list of the WHO regions for each country
who_regions = pd.read_csv(".../who-regions.csv")
who_regions = who_regions.rename(columns = {"Entity": "country", "WHO region": "who_region"})
who_regions = who_regions.replace(country_dict)
countries = countries.merge(who_regions[["country", "who_region"]], on = "country", how = "left")

# assign a WHO region to countries without one in the previous dataset
countries.loc[countries["who_region"].isna() & countries["un_subregion"].isin(["Latin America and the Caribbean", "Northern America"]), "who_region"] = "Americas"
countries.loc[countries["who_region"].isna() & countries["un_subregion"].isin(["Eastern Asia", "Melanesia"]), "who_region"] = "Western Pacific"
countries.loc[countries["who_region"].isna() & countries["un_subregion"] == "Eastern Asia", "who_region"] = "Western Pacific"
countries.loc[(countries["who_region"].isna()) & (countries["un_subregion"] == "South-eastern Asia"), "who_region"] = "South-East Asia"
countries.loc[countries["who_region"].isna() & countries["un_subregion"].isin(["Southern Europe", "Western Europe"]), "who_region"] = "Europe"
countries.loc[(countries["who_region"].isna()) & (countries["un_subregion"] == "Western Asia"), "who_region"] = "Eastern Mediterranean"
countries.loc[(countries["who_region"].isna()) & (countries["un_subregion"] == "Sub-Saharan Africa"), "who_region"] = "Africa"
countries.loc[(countries["who_region"].isna()) & (countries["un_subregion"] == "Polynesia"), "who_region"] = "Western Pacific"
countries.loc[(countries["who_region"].isna()) & (countries["un_subregion"] == "Federated States of Micronesia"), "who_region"] = "Western Pacific"

# load in and do minor processing of a list of the World Bank Income Groups for each country
wb = pd.read_excel(".../world_bank_classification.xlsx")
wb = wb.rename(columns = {"Economy": "country", "Income group":"wb_inc_group"})
wb = wb.replace(country_dict)

# create a unified list of countries with regional and income groups
countries = countries.merge(wb[["country", "wb_inc_group"]], on = "country", how = "left")

# assign a World Bank Income Group to countries without one in the prevoius dataset
hic_countries = ["Anguilla", "Bonaire, Saint Eustatius and Saba", "British Virgin Islands",
                 "Cook Islands", "French Guiana", "Greenland", "Guadeloupe",
                 "La Reunion", "Liechtenstein", "Martinique", "Montserrat",
                 "Niue", "Saint Barthelemy"]
countries.loc[countries["country"].isin(hic_countries), "wb_inc_group"] = "High income"
countries.loc[countries["country"].isin(["Mayotte", "Venezuela"]), "wb_inc_group"] = "Upper middle income"

# save the output
countries.to_excel(".../country_list.xlsx", index = False)

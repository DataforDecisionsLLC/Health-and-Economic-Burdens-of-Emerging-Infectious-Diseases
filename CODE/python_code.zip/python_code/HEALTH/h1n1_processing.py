# -*- coding: utf-8 -*-
"""
h1n1_processing.py

Description: Processing the cases and deaths during the H1N1 pandemic and calculates DALYs.

Created = 6 May 2024
Modified = 30 September 2024

Inputs:
    1. Dawood_Appendix_Tables.xlsx 
    2. country_list.xlsx (created in country_list.py)
    3. country_names.xlsx
    4. discounted_LE_age_0_100.dta (created in make_discounted_LE_age_0_100.do)
    5. covid_country_ylds_per_case.xlsx (created in covid_dalys.py)

Outputs:
    1. h1n1_cases_deaths.xlsx
    2. h1n1_dalys.xlsx
    
Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the files country_list.py,
       make_discounted_LE_age_0_100.do, and covid_dalys.py. Thus, those three
       prorams must be run prior to running this program.
"""

# %% import libraries
import pandas as pd
import numpy as np
import country_converter as coco
cc = coco.CountryConverter()

# %% process Dawood Appendix Table 8

# load in the (age-group-specific) respiratory deaths due to H1N1
table8 = pd.read_excel(".../Dawood_Appendix_Tables.xlsx", sheet_name="Table 8")

# identify the 25th and 75 percentiles from the unformatted data
table8[["All ages", "0-17 years", "18-64 years", ">64 years"]] = table8[["All ages", "0-17 years", "18-64 years", ">64 years"]].astype(str)
table8['all_ages_25th'] = table8['All ages'].str.split('–', n=1).str.get(0).str.replace(",", "")
table8['all_ages_75th'] = table8['All ages'].str.split('–', n=1).str.get(1).str.replace(",", "")
table8['0_17_25th'] = table8['0-17 years'].str.split('–', n=1).str.get(0).str.replace(",", "")
table8['0_17_75th'] = table8['0-17 years'].str.split('–', n=1).str.get(1).str.replace(",", "")
table8['18_64_25th'] = table8['18-64 years'].str.split('–', n=1).str.get(0).str.replace(",", "")
table8['18_64_75th'] = table8['18-64 years'].str.split('–', n=1).str.get(1).str.replace(",", "")
table8['over64_25th'] = table8['>64 years'].str.split('–', n=1).str.get(0).str.replace(",", "")
table8['over64_75th'] = table8['>64 years'].str.split('–', n=1).str.get(1).str.replace(",", "")

# drop all the bad data columns
table8 = table8.drop(columns=["All ages", "0-17 years", "18-64 years", ">64 years"]).dropna()

# convert all the values to integers
table8['all_ages_25th'] = table8['all_ages_25th'].astype(int)
table8['all_ages_75th'] = table8['all_ages_75th'].astype(int)
table8['0_17_25th'] = table8['0_17_25th'].astype(int)
table8['0_17_75th'] = table8['0_17_75th'].astype(int)
table8['18_64_25th'] = table8['18_64_25th'].astype(int)
table8['18_64_75th'] = table8['18_64_75th'].astype(int)
table8['over64_25th'] = table8['over64_25th'].astype(int)
table8['over64_75th'] = table8['over64_75th'].astype(int)

# find the value in the middle of the 25th and 75th percentiles
table8["All"] = (table8["all_ages_25th"] + table8["all_ages_75th"])/2
table8["0-17"] = (table8["0_17_25th"] + table8["0_17_75th"])/2
table8["18-64"] = (table8["18_64_25th"] + table8["18_64_75th"])/2
table8["65-99"] = (table8["over64_25th"] + table8["over64_75th"])/2

# only keep the relevant columns
table8 = table8[["country", "All", "0-17", "18-64", "65-99"]]

# %% process Dawood Appendix Table 9

# load in the (age-invariant) respiratory and cardiovascular deaths 
table9 = pd.read_excel(".../Dawood_Appendix_Tables.xlsx", sheet_name="Table 9")

# identify the 25th and 75 percentiles from the unformatted data
table9[["country", "All ages"]] = table9[["country", "All ages"]].astype(str)
table9['all_ages_25th'] = table9['All ages'].str.split('–', n=1).str.get(0).str.replace(",", "")
table9['all_ages_75th'] = table9['All ages'].str.split('–', n=1).str.get(1).str.replace(",", "")

# drop missing values
table9 = table9.drop(columns=["All ages"]).dropna()

# get the middle value for respiratory and cardiovascular deaths
table9['all_ages_25th'] = table9['all_ages_25th'].astype(int)
table9['all_ages_75th'] = table9['all_ages_75th'].astype(int)
table9["All"] = (table9["all_ages_25th"] + table9["all_ages_75th"])/2

# only keep the relevant columns
table9 = table9[["country", "All"]]

# create new, empty columns to split the deaths among age gorups
table9["0-17"] = 0
table9["18-64"] = 0
table9["65-99"] = 0

# use the age groups from just the respiratory deaths (table 8) to construct an age structure of deaths for all deaths
for c in table9.country.unique():
    prop_0_17 = table8.loc[table8["country"] == c, "0-17"].values[0]/table8.loc[table8["country"] == c, "All"].values[0]
    prop_18_64 = table8.loc[table8["country"] == c, "18-64"].values[0]/table8.loc[table8["country"] == c, "All"].values[0]
    prop_65_99 = table8.loc[table8["country"] == c, "65-99"].values[0]/table8.loc[table8["country"] == c, "All"].values[0]
    table9.loc[table9["country"] == c, "0-17"] = table9.loc[table8["country"] == c, "All"].values[0]*prop_0_17
    table9.loc[table9["country"] == c, "18-64"] = table9.loc[table8["country"] == c, "All"].values[0]*prop_18_64
    table9.loc[table9["country"] == c, "65-99"] = table9.loc[table8["country"] == c, "All"].values[0]*prop_65_99

# remove no longer existing countries and convert the names to short form
table9 = table9[table9.country != "Serbia and Montenegro"]
table9["country"] = cc.convert(names = table9["country"], to = 'name_short')

#load in a list of the countries
country_list = pd.read_excel(".../country_list.xlsx")

#loading a dictionary that is used to rename countries
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

# rename the countries to the authors' preferred naming convention
table9 = table9.replace(country_dict)

# %% calculate cases using CFRs and deaths from Dawood et al.

# CFRs from Dawood et al. Table 1.
cfr_0_17 = np.mean([0.00005, 0.00005, 0.00004, 0.00002, 0.00008, 0.00013])
cfr_18_64 = np.mean([0.00027, 0.00054, 0.00035, 0.00018, 0.00028, 0.00159])
cfr_65_99 = np.mean([0.00092, 0.00122, 0.00308, 0.00090])

# create a dataframe to calculate cases
h1n1_df = table9.copy()
h1n1_df = h1n1_df.rename(columns = {"All": "deaths", "0-17": "deaths_0_17",
                                     "18-64": "deaths_18_64", "65-99": "deaths_65_99"})

# estimate number of cases for each age group by dividing deaths by the CFR
h1n1_df["cases_0_17"] = h1n1_df["deaths_0_17"]/cfr_0_17
h1n1_df["cases_18_64"] = h1n1_df["deaths_18_64"]/cfr_18_64
h1n1_df["cases_65_99"] = h1n1_df["deaths_65_99"]/cfr_65_99

# calculate total cases
h1n1_df["cases"] = h1n1_df[["cases_0_17", "cases_18_64", "cases_65_99"]].sum(axis=1)
h1n1_df["year"] = 2009

# save the output
h1n1_df = h1n1_df[["country", "year", "deaths", "cases"]]
h1n1_df.to_excel(".../h1n1_cases_deaths.xlsx", index = False)

# %% calculate DALYs lost

# load in the life expectancy data
discounted_LE = pd.read_stata(".../discounted_LE_age_0_100.dta")

# create a dataframe to process DALYs
h1n1_age_structure = table9.copy()
h1n1_age_structure["year"] = 2009
h1n1_age_structure = h1n1_age_structure[["country", "year", "0-17", "18-64", "65-99"]]
h1n1_age_long = pd.melt(h1n1_age_structure, id_vars=['country', "year"], value_vars=["0-17", "18-64", "65-99"])

# split age group data into single-ages
def split_age_groups(df):
    """
    Evenly divides data from age groups among the ages in that group

    Parameters
    ----------
    df : data frame
        Data frame containing the age group data.

    Returns
    -------
    pd.DataFrame(rows)
        Data frame containing the single-age data.
    """
    rows = []
    for index, row in df.iterrows():
        age_range = row['variable'].split('-')
        start_age = int(age_range[0])
        end_age = int(age_range[1])
        for age in range(start_age, end_age + 1):
            new_row = {'country': row["country"], 'year': row['year'], 'age': age, "deaths_age": row["value"]/len(range(start_age, end_age + 1))}
            rows.append(new_row)
    return pd.DataFrame(rows)

# split the H1N1 deaths among all ages
h1n1_age_structure_single_age = split_age_groups(h1n1_age_long)

# calculate YLLs as age-specific deaths multiplited by age-specific discounted life expectancy
h1n1_ylls = pd.merge(h1n1_age_structure_single_age, discounted_LE, on = ["country", "year", "age"], how = "left")
h1n1_ylls["YLLs"] = h1n1_ylls["deaths_age"]*h1n1_ylls["LE"]

# calculate YLLs per case and per death
h1n1_ylls_agg = h1n1_ylls.groupby(["country", "year"])["YLLs"].sum().reset_index()
h1n1_ylls_per_case = pd.merge(h1n1_ylls_agg, h1n1_df, on = ["country", "year"], how='outer')
h1n1_ylls_per_case["YLLs_per_case"] = h1n1_ylls_per_case["YLLs"]/h1n1_ylls_per_case["cases"]
h1n1_ylls_per_case["YLLs_per_fatal_case"] = h1n1_ylls_per_case["YLLs"]/h1n1_ylls_per_case["deaths"]

# load in COVID YLDs, which we use as a proxy for H1N1 YLDs
covid_ylds = pd.read_excel(".../covid_country_ylds_per_case.xlsx")

# merge COVID YLDs to H1N1 data
h1n1_ylds = pd.merge(h1n1_df, covid_ylds[["country", "YLDs_per_case"]], on = ["country"], how = "left")

# calculate DALYs per case as the sum of YLDs per case and YLLs per case
h1n1_dalys = pd.merge(h1n1_ylds[["country", "year", "YLDs_per_case"]], h1n1_ylls_per_case[["country", "year", "YLLs_per_case", "YLLs_per_fatal_case"]], on = ["country", "year"], how = "outer")
h1n1_dalys = h1n1_dalys.replace({np.nan: 0})
h1n1_dalys["DALYs_per_case"] = h1n1_dalys["YLDs_per_case"] + h1n1_dalys["YLLs_per_case"]

# save the output
h1n1_dalys.to_excel(".../h1n1_dalys.xlsx", index = False)

# -*- coding: utf-8 -*-
"""
mers_dalys.py

Description: Processes DALYs for MERS.

Created: 26 March 2024
Modified: 30 September 2024

Inputs:
    1. mers_cases_deaths.xlsx
    2. country_names.xlsx
    3. covid_country_ylds_per_case.xlsx (created in covid_dalys.py)
    4. discounted_LE_age_0_100.dta (created in make_discounted_LE_age_0_100.do)
    5. mers_age_structure.xlsx
    
Outputs:
    1. mers_symp_cases_deaths.xlsx
    2. mers_dalys.xlsx

Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the programs country_list.py
       and make_discounted_LE_age_0_100.do. Thus, those two programs must be run
       prior to running this program.
"""

#%% import libraries
import pandas as pd
import numpy as np

#%% load in data and process YLDs

# load in mers data and rename countries
mers = pd.read_excel(".../mers_cases_deaths.xlsx", sheet_name = "Data")
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()
mers = mers.replace(country_dict)
mers["year"] = mers["year"].astype(str)

# we assume a 22.4% asymptomatic rate
asymp_rate = 0.224
symp_rate = 1 - asymp_rate

# we calculate symptomatic cases and ensure they are at least as large as the number of deaths
mers["cases2"] = mers["cases"]*symp_rate
mers['cases'] = np.where((mers['cases2'] < mers["deaths"]), mers["deaths"], mers["cases2"])
mers = mers.drop(columns = "cases2")

# Some MERS data comes in ranges of years. The following for-loops disaggregate 
# the data into single years.
def split_years(df):
    rows = []
    for index, row in df.iterrows():
        if "-" in row["year"]:
            year_range = row['year'].split('-')
            start_year = int(year_range[0])
            end_year = int(year_range[1])
            for year in range(start_year, end_year + 1):
                new_row = {'country': row["country"], "year": year, 'cases': row['cases']/len(range(start_year, end_year + 1)), 'deaths': row['deaths']/len(range(start_year, end_year + 1)), "source": row["source"], "notes": "range"}
                rows.append(new_row)
    return pd.DataFrame(rows)

# split the data 
mers_split = split_years(mers)

# combine pre-existing and split data
mers = pd.concat([mers, mers_split])
mers["year"] = mers["year"].astype(str)

# drop data that spans multiple years      
for index, row in mers.iterrows():
    if "-" in row["year"]:
        mers = mers.drop(index)

mers = mers.sort_values(["country", "year"]).reset_index(drop=True)

""" 
For some country-years, we have more than one source of data. We establish a priority criteria
to choose data.
    1. Our least-preferred data is that which comes in a range of years.
    2. Our second-least-preferred data is that for which we had to estimate the values using a plot digitizer.
"""

mers_country_year_counts = mers[["country", "year"]].value_counts().reset_index()

mers = mers[~((mers["country"] == "Saudi Arabia") & ((mers["year"] == "2012") | (mers["year"] == "2013")) & (mers["notes"] == "range"))]
mers = mers[~((mers["country"] == "Saudi Arabia") & ((mers["year"] == "2014") | (mers["year"] == "2015")) & (mers["notes"] == "plot digitizer"))]
mers = mers[~((mers["country"] == "United States") & (mers["year"] == "2014") & (mers["source"] == "ECDC"))]
mers = mers[~((mers["country"] == "South Korea") & (mers["year"] == "2015") & (mers["source"] == "ECDC"))]

mers["year"] = mers["year"].astype(int)

# save the cases and deaths as an output
mers.to_excel(".../mers_symp_cases_deaths.xlsx", index = False)

# load in COVID-19 YLDs, which we use as a proxy for MERS YLDs
covid_ylds = pd.read_excel(".../covid_country_ylds_per_case.xlsx")

mers_ylds = pd.merge(mers, covid_ylds[["country", "YLDs_per_case"]], on = ["country"], how = "left")

# %% process YLLs

# load in discounted life expectancy data
discounted_LE = pd.read_stata(".../discounted_LE_age_0_100.dta")

# load in age structure of MERS deaths
mers_age_structure = pd.read_excel(".../mers_age_structure.xlsx", sheet_name = "age structure")

# rename one of age groups to fit our convention
mers_age_structure = mers_age_structure.replace({"90+": "90-99"})

# MERS data arrive in age groups, the following code evenly divides deaths among 
# the ages in each group
def split_age_groups(df):
    rows = []
    for index, row in df.iterrows():
        age_range = row['age'].split('-')
        start_age = int(age_range[0])
        end_age = int(age_range[1])
        for age in range(start_age, end_age + 1):
            new_row = {'age': age, "proportion": row["age_structure_deaths"]/len(range(start_age, end_age + 1))}
            rows.append(new_row)
    return pd.DataFrame(rows)

mers_age_structure_single_age = split_age_groups(mers_age_structure)
mers_ages = mers.loc[mers.index.repeat(100)].reset_index(drop=True)
list_ages = list(range(0,100))
mers_ages['age'] = np.tile(list_ages, len(mers_ages)//len(list_ages))

# combine mers age sturcture of deaths with deaths data                         
mers_deaths_ages = pd.merge(mers_ages, mers_age_structure_single_age, on = "age", how = "left")

# calculate deaths in each age
mers_deaths_ages["deaths_age"] = mers_deaths_ages["deaths"]*mers_deaths_ages["proportion"]

# multiple deaths by discounted life expectancy to get YLLs
mers_ylls = pd.merge(mers_deaths_ages, discounted_LE, on = ["country", "year", "age"], how = "left")
mers_ylls["YLLs"] = mers_ylls["deaths_age"]*mers_ylls["LE"]

# calculate YLLs per case and per death
mers_ylls_agg = mers_ylls.groupby(["country", "year"])["YLLs"].sum().reset_index()
mers_ylls_per_case = pd.merge(mers_ylls_agg, mers, on = ["country", "year"], how='outer')
mers_ylls_per_case["YLLs_per_case"] = mers_ylls_per_case["YLLs"]/mers_ylls_per_case["cases"]
mers_ylls_per_case["YLLs_per_fatal_case"] = mers_ylls_per_case["YLLs"]/mers_ylls_per_case["deaths"]

# %% mers dalys

# combine YLLs per case and YLDs per case to get DALYs per case
mers_dalys = pd.merge(mers_ylds[["country", "year", "YLDs_per_case"]], mers_ylls_per_case[["country", "year", "YLLs_per_case", "YLLs_per_fatal_case"]], on = ["country", "year"], how = "outer")
mers_dalys = mers_dalys.replace({np.nan: 0})
mers_dalys["DALYs_per_case"] = mers_dalys["YLDs_per_case"] + mers_dalys["YLLs_per_case"]

# save the output
mers_dalys.to_excel(".../mers_dalys.xlsx", index = False)

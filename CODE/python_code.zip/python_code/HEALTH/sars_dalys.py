# -*- coding: utf-8 -*-
"""
sars_dalys.py

Description: Processes DALYs for SARS.

Created: 26 March 2024
Modified: 30 September 2024

Inputs:
    1. sars_cases_deaths.xlsx
    2. country_names.xlsx
    3. covid_country_ylds_per_case.xlsx (created in covid_dalys.py)
    4. discounted_LE_age_0_100.dta (created in make_discounted_LE_age_0_100.do)
    5. sars_age_structure.xlsx
    
Outputs:
    1. sars_dalys.xlsx

Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the programs country_list.py
       and make_discounted_LE_age_0_100.do. Thus, those two programs must be run
       prior to running this program.
"""

#%% import libraries
import pandas as pd
import numpy as np

#%% load in data and process YLDs

# load in data and rename countries
sars = pd.read_excel(".../sars_cases_deaths.xlsx", sheet_name = "Data")
country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()
sars = sars.replace(country_dict)
sars["year"] = sars["year"].astype(str)

# SARS data comes split across years. We evenly divide such data between years
def split_years(df):
    rows = []
    for index, row in df.iterrows():
        if "-" in row["year"]:
            year_range = row['year'].split('-')
            start_year = int(year_range[0])
            end_year = int(year_range[1])
            for year in range(start_year, end_year + 1):
                new_row = {'country': row["country"], "year": year, 'cases': row['cases']/len(range(start_year, end_year + 1)), 'deaths': row['deaths']/len(range(start_year, end_year + 1)), "source": row["source"], "notes": "range"}
                rows.append(new_row)
    return pd.DataFrame(rows)

sars = split_years(sars)
sars = sars.sort_values(["country", "year"]).reset_index(drop=True)
sars_country_year_counts = sars[["country", "year"]].value_counts().reset_index()
sars["year"] = sars["year"].astype(int)

# load in COVID YLDs, which we use as a proxy for SARS YLDs
covid_ylds = pd.read_excel(".../covid_country_ylds_per_case.xlsx")

sars_ylds = pd.merge(sars, covid_ylds[["country", "YLDs_per_case"]], on = ["country"], how = "left")

"""
Hong Kong and Macao do not appear in the COVID YLDs, so they are missing data for the YLDs per case.
We assign the YLDs per case from China to these countries.
"""

sars_ylds.loc[sars_ylds["country"].isin(["China, Hong Kong SAR", "China, Macao SAR"]), "YLDs_per_case"] = sars_ylds.loc[sars_ylds["country"] == "China", "YLDs_per_case"].values[0]

# %% process YLLs

# load in discount life expectancy data
discounted_LE = pd.read_stata(".../discounted_LE_age_0_100.dta")

# load in the age sturcture of SARS deaths
sars_age_structure = pd.read_excel(".../sars_age_structure.xlsx", sheet_name = "age structure")

# rename an age group to our convention
sars_age_structure = sars_age_structure.replace({"75+": "75-99"})

# SARS deaths come in age groups. We evenly divide the data across ages in those groups.
def split_age_groups(df):
    rows = []
    for index, row in df.iterrows():
        age_range = row['age'].split('-')
        start_age = int(age_range[0])
        end_age = int(age_range[1])
        for age in range(start_age, end_age + 1):
            new_row = {'age': age, "proportion": row["age_structure_deaths"]/len(range(start_age, end_age + 1))}
            rows.append(new_row)
    return pd.DataFrame(rows)

sars_age_structure_single_age = split_age_groups(sars_age_structure)
sars_ages = sars.loc[sars.index.repeat(100)].reset_index(drop=True)
list_ages = list(range(0,100))
sars_ages['age'] = np.tile(list_ages, len(sars_ages)//len(list_ages))

# combine SARS deaths and age structure of deaths data                        
sars_deaths_ages = pd.merge(sars_ages, sars_age_structure_single_age, on = "age", how = "left")

# calculate SARS deaths for each age
sars_deaths_ages["deaths_age"] = sars_deaths_ages["deaths"]*sars_deaths_ages["proportion"]

# calculate YLLs as the product of deaths and discounted life expectancy
sars_ylls = pd.merge(sars_deaths_ages, discounted_LE, on = ["country", "year", "age"], how = "left")
sars_ylls["YLLs"] = sars_ylls["deaths_age"]*sars_ylls["LE"]

# We calculate YLLs per case and per death
sars_ylls_agg = sars_ylls.groupby(["country", "year"])["YLLs"].sum().reset_index()
sars_ylls_per_case = pd.merge(sars_ylls_agg, sars, on = ["country", "year"], how='outer')
sars_ylls_per_case["YLLs_per_case"] = sars_ylls_per_case["YLLs"]/sars_ylls_per_case["cases"]
sars_ylls_per_case["YLLs_per_fatal_case"] = sars_ylls_per_case["YLLs"]/sars_ylls_per_case["deaths"]

# %% sars dalys

# we combine YLLs per case and YLDs per case to get DALYs per case
sars_dalys = pd.merge(sars_ylds[["country", "year", "YLDs_per_case"]], sars_ylls_per_case[["country", "year", "YLLs_per_case", "YLLs_per_fatal_case"]], on = ["country", "year"], how = "outer")
sars_dalys = sars_dalys.replace({np.nan: 0})
sars_dalys["DALYs_per_case"] = sars_dalys["YLDs_per_case"] + sars_dalys["YLLs_per_case"]

# save the output
sars_dalys.to_excel(".../sars_dalys.xlsx", index = False)

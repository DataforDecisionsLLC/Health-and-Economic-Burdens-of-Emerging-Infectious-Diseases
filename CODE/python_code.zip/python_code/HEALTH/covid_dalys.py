# -*- coding: utf-8 -*-
"""
covid_dalys.py

Description: Processes DALYs for COVID-19.

Created: 19 March 2024
Modified: 30 September 2024

Inputs:
    1. Data Explorer - Data - COVID-19 - Deaths, YLDs, Incidence, Prevalence - Number in China, North Korea, Taiwan...  2024-07-22 18-14-06.csv
    2. Data Explorer - Data - Asymptomatic COVID-19 cases - Prevalence - Number in China, North Korea, Taiwan, Camb...  2024-07-26 10-24-12.csv
    3. Data Explorer - Data - Other COVID-19 pandemic-related outcomes - Deaths - Number in China, North Korea, Tai...  2024-07-22 18-08-38.csv
    4. discounted_LE_age_0_100.dta (created in make_discounted_LE_age_0_100.do)
    5. country_names.xlsx
    
Outputs:
    1. covid_asymp_ratios.xlsx
    2. covid_dalys.xlsx
    3. covid_country_ylds_per_case.xlsx
    
Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the program make_discounted_LE_age_0_100.do.
       Thus, make_discounted_LE_age_0_100.do must be run prior to running this program.
"""

# %% import libraries
import pandas as pd
import numpy as np

# %% load in data and perform minor data management

# load in select GBD data for COVID, which contains YLDs, incidience, and deaths.
covid_data = pd.read_csv(".../Data Explorer - Data - COVID-19 - Deaths, YLDs, Incidence, Prevalence - Number in China, North Korea, Taiwan...  2024-07-22 18-14-06.csv")
asymp_data = pd.read_csv(".../Data Explorer - Data - Asymptomatic COVID-19 cases - Prevalence - Number in China, North Korea, Taiwan, Camb...  2024-07-26 10-24-12.csv")
opo_data = pd.read_csv(".../Data Explorer - Data - Other COVID-19 pandemic-related outcomes - Deaths - Number in China, North Korea, Tai...  2024-07-22 18-08-38.csv")

covid_data = pd.concat([covid_data, asymp_data, opo_data])

# load in discounted life expectancy file, used to calculate 
discounted_LE = pd.read_stata(".../discounted_LE_age_0_100.dta")

# reformat ages to be coherent ranges
covid_data = covid_data.replace({"Under 5": "0 to 4", "95 and above": "95 to 99"})
# reformat column names to be easy to work with
covid_data = covid_data.rename(columns={"Location": "country", "Year":"year"})

country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

covid_data = covid_data.replace(country_dict)

# %% process prevalence
"""
In this block, we calculate the proportion of cases that are symptomatic
"""

prev_df = covid_data.query("Measure == 'Prevalence'")
prevs = prev_df.groupby(["country", "year", "Condition"])["Value"].sum().reset_index()

prevs = prevs.pivot(index=["country", "year"], columns='Condition', values='Value').reset_index()
prevs["asymp_ratio"] = prevs["Asymptomatic COVID-19 cases"]/prevs["COVID-19"]
for t in [2020, 2021]:
    year_avg = prevs.loc[prevs["year"] == t, "asymp_ratio"].median()
    prevs.loc[(prevs["Asymptomatic COVID-19 cases"].isna()) & (prevs["COVID-19"] > 0) & (prevs["year"] == t), "asymp_ratio"] = year_avg

asymp_df = prevs[prevs.asymp_ratio.notna()]
asymp_df.loc[asymp_df['asymp_ratio'] > 1, "asymp_ratio"] = 1
asymp_df[["country", "year", "asymp_ratio"]].to_excel(".../covid_asymp_ratios.xlsx")

asymp_df['symp_ratio'] = 1 - asymp_df["asymp_ratio"]

# %% create a Class that processes the DALYs.

class Calculate_DALYs:
    def __init__(self):
        self.scenario = None
        self.data = None
        self.ylds_per_case = None
        self.grouped_cases = None
        self.life_exp = None
        self.ylls_per_case = None
        self.dalys = None
        
    def process_DALYs_IHME(self, scenario="Value", data = covid_data, life_exp=discounted_LE):
        """
        Takes in a data frame that must contain country, year, cases, and YLDs to estimate YLDs per case.

        Parameters
        ----------
        scenario : string, optional
            The IHME scenario to estimate. Options are "Value", "Lower", or "Upper". The default is "Value".
        data : data frame, optional
            The data frame containg the data. The default is covid_data.
        life_exp : data frame, optional
            The data frame containing discounted life expectancies. The default is discounted_LE.

        Returns
        -------
        data frame
            Data frame containing DALYs per case.

        """
        self.scenario = scenario
        self.data = data
        self.life_exp = life_exp
        
        # create a data frame of cases
        cases = data.query("Measure == 'Incidence'")
        cases = cases.merge(asymp_df, on = ["country", "year"], how = "left")
        cases = cases.assign(Value=cases[["Value", "symp_ratio"]].prod(1, skipna=True))
        cases = cases.assign(Lower=cases[["Lower", "symp_ratio"]].prod(1, skipna=True))
        cases = cases.assign(Upper=cases[["Upper", "symp_ratio"]].prod(1, skipna=True))
        # group cases by country and year
        grouped_cases = cases.groupby(["country", "year"])[scenario].sum().reset_index()
        self.grouped_cases = grouped_cases
        
        # create a data frame of YLDs
        ylds = data.query("Measure == 'YLDs'")
        # group YLDs by country and year
        grouped_ylds = ylds.groupby(["country", "year"])[scenario].sum().reset_index()

        # merge the grouped cases and YLDs to a single data frame
        ylds_per_case = pd.merge(grouped_cases, grouped_ylds, on=['country', 'year'], how='outer').rename(columns={scenario+"_x": 'Cases', scenario+"_y": 'YLDs'})
        # divide YLDs by cases in each country year
        ylds_per_case["YLDs_per_case"] = ylds_per_case["YLDs"]/ylds_per_case["Cases"]
        # drop any missing values
        self.ylds_per_case = ylds_per_case
                
        # create a data frame of deaths 
        deaths = data.query("Measure == 'Deaths'")
        # group deaths by country and year
        grouped_deaths = deaths.groupby(['country', 'year'])[scenario].transform('sum')
        #deaths["Proportion"] = deaths[scenario]/grouped_deaths
        # drop any missing values
        deaths = deaths.dropna(subset=[scenario])
        
        # the IHME data comes in 5-year age groups. The following for-loops disaggregate 
        # the data into single ages.
        # create an empty list 
        rows = []
        # for each row in the deaths data
        for index, row in deaths.iterrows():
            # get the first and last ages in the age range
            age_range = row['Age'].split(' to ')
            # get the first age
            start_age = int(age_range[0])
            # get the last age
            end_age = int(age_range[1])
            # for the ages in the age range
            for age in range(start_age, end_age + 1):
                # create a new row that divides the deaths evenly among the ages in the age range
                new_row = {'country': row["country"], "year": row["year"], 'age': age, "deaths": row[scenario]/len(range(start_age, end_age + 1))}
                # append the new row to the list of rows
                rows.append(new_row)
        # create a data frame that consist of the single age data
        deaths_single_age = pd.DataFrame(rows)
        
        # merge the deaths and life expectancy data into a single data frame
        ylls = pd.merge(deaths_single_age, discounted_LE, on=['country','year','age'], how='left')
        # mutliply the number of deaths by the life expectancy to get YLLs
        ylls["YLLs"] = ylls["deaths"]*ylls["LE"]
        
        # group YLLs by country and year
        ylls_agg = ylls.groupby(["country", "year"])[["YLLs", "deaths"]].sum().reset_index()
        # merge YLLs to cases data
        ylls_per_case = pd.merge(ylls_agg, self.grouped_cases, on = ["country", "year"], how='outer').rename(columns={scenario: 'Cases'})
        # divide YLLs by number of cases to get YLLs per case
        ylls_per_case["YLLs_per_case"] = ylls_per_case["YLLs"]/ylls_per_case["Cases"]
        ylls_per_case["YLLs_per_fatal_case"] = ylls_per_case["YLLs"]/ylls_per_case["deaths"]
        # drop any missing values
        self.ylls_per_case = ylls_per_case
        
        # create simple data frames with only country, year, and YLDs/YLLs per case
        ylds_simple = self.ylds_per_case[["country", "year", "YLDs_per_case"]]
        ylls_simple = self.ylls_per_case[["country", "year", "YLLs_per_case", "YLLs_per_fatal_case"]]

        # combine the simple data frames together
        dalys = pd.merge(ylds_simple, ylls_simple, on = ["country", "year"], how = "outer")
        # calculate DALYs per case by adding YLDs and YLLs per case
        dalys["DALYs_per_case"] = dalys["YLDs_per_case"] + dalys["YLLs_per_case"]
        dalys = dalys[dalys["year"] > 1999].replace({np.nan: 0, np.inf: 0})
        self.dalys = dalys
        
        return dalys

# %% use the Class to calculate DALYs for the three IHME scenarios.

# create a COVID class object
covid = Calculate_DALYs()
# calculate DALYs using the median, upper, and lower scenarios
covid_dalys_median = covid.process_DALYs_IHME(scenario = "Value", data = covid_data, life_exp=discounted_LE)
covid_dalys_upper = covid.process_DALYs_IHME(scenario = "Upper", data = covid_data, life_exp=discounted_LE)
covid_dalys_lower = covid.process_DALYs_IHME(scenario = "Lower", data = covid_data, life_exp=discounted_LE)

# add these data frames to an Excel file
writer = pd.ExcelWriter('.../covid_dalys.xlsx',engine='xlsxwriter')
covid_dalys_median.to_excel(writer,sheet_name='median',index = False)
covid_dalys_upper.to_excel(writer,sheet_name='upper',index = False)
covid_dalys_lower.to_excel(writer,sheet_name='lower',index = False)
writer.close()

# %% calculate YLDs at the country-level (rather than country-year) for use in MERS and SARS calculations.

# calculate COVID cases and group them by country
covid_cases = covid_data.query("Measure == 'Incidence'")
country_cases = covid_cases.groupby(["country"])["Value"].sum().reset_index()

# adjust for asymptomatic cases
country_asymp = asymp_df.groupby("country")[["Asymptomatic COVID-19 cases", "COVID-19"]].sum().reset_index()
country_asymp["asymp_ratio"] = country_asymp["Asymptomatic COVID-19 cases"]/country_asymp["COVID-19"]
country_asymp["symp_ratio"] = 1- country_asymp["asymp_ratio"]
avg = country_asymp["symp_ratio"].median()
country_asymp.loc[(country_asymp["Asymptomatic COVID-19 cases"].isna()) & (country_asymp["COVID-19"] > 0), "symp_ratio"] = avg

country_cases = country_cases.merge(country_asymp[["country", "symp_ratio"]], on = "country", how = "left")
country_cases = country_cases.assign(Value=country_cases[["Value", "symp_ratio"]].prod(1, skipna=True))

# calculate COVID YLDs and group them by country
covid_ylds = covid_data.query("Measure == 'YLDs'")
country_ylds = covid_ylds.groupby(["country"])["Value"].sum().reset_index()

# calculate country-specific YLDs per case
country_ylds_per_case = pd.merge(country_cases, country_ylds, on=['country'], how='outer').rename(columns={'Value_x': 'Cases', 'Value_y': 'YLDs'})
country_ylds_per_case["YLDs_per_case"] = country_ylds_per_case["YLDs"]/country_ylds_per_case["Cases"]

# save the output
country_ylds_per_case.to_excel(".../covid_country_ylds_per_case.xlsx", index = False)

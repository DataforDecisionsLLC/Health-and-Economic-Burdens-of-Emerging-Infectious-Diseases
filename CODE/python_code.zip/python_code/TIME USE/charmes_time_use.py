# -*- coding: utf-8 -*-
"""
charmes_time_use.py

Description: Assigns time use data to countries based on the 
Charmes (2015) and Charmes (2019) time use data.

Created = 5 April 2024
Modified = 30 September 2024

Inputs:
    1. country_list.xlsx (created in country_list.py)
    2. country_names.xlsx
    3. WPP2022_POP_F01_2_POPULATION_SINGLE_AGE_MALE.xlsx
    4. WPP2022_POP_F01_3_POPULATION_SINGLE_AGE_FEMALE.xlsx
    5. Charmes2019_unpaid_paid_work.xlsx
    6. Charmes_2015.xlsx

Outputs:
    1. time_use_data.xlsx

Notes:
    1. The user should replace "..." with the appropriate path.
    2. This program is dependent on the output of the program country_list.py. 
       Thus, country_list.py must be run prior to running this program.
"""

# %% load in packages
import pandas as pd
import numpy as np

# %% load in countries

#load in IHME data
countries = pd.read_excel(".../country_list.xlsx")

country_names = pd.read_excel(".../country_names.xlsx")
country_dict = country_names.set_index('non_standard_name')['standard_name'].to_dict()

# %% load in the demographic information from the Male and Female WPP data.

#load in male populations from UN WPP
male = pd.read_excel(".../WPP2022_POP_F01_2_POPULATION_SINGLE_AGE_MALE.xlsx",
                     sheet_name = "Estimates", header = 16)

#load in female populations from UN WPP
female = pd.read_excel(".../WPP2022_POP_F01_3_POPULATION_SINGLE_AGE_FEMALE.xlsx",
                     sheet_name = "Estimates", header = 16)

#only include 2022 data
male2022 = male[male["Year"] == 2021]
female2022 = female[female["Year"] == 2021]

#change the column name of the country variable to an easily usable title
male2022 = male2022.rename(columns = {"Region, subregion, country or area *":
                                          "country"})

female2022 = female2022.rename(columns = {"Region, subregion, country or area *":
                                          "country"})

#perform the renaming and remove all countries that are not in the population data file.
male2022 = male2022.replace(country_dict)
female2022 = female2022.replace(country_dict)

#only keep countries that are in our data
male2022 = male2022[male2022["country"].isin(countries.country.unique())]
female2022 = female2022[female2022["country"].isin(countries.country.unique())]

#find the column number for the country and Year columns. 
#also get the number of the last column in the data.
a = male2022.columns.get_loc('country')
b = male2022.columns.get_loc('Year')
c = len(male2022.columns)

#subset the population data to keep only the relevant columns
male_df = male2022.iloc[:, np.r_[a, b:c]]
female_df = female2022.iloc[:, np.r_[a, b:c]]

#sum the populations between age 15 and 100+ to get the full "adult" population size.
male_df["adult"] = male_df.loc[:, 15:"100+"].sum(axis = 1)
female_df["adult"] = female_df.loc[:, 15:"100+"].sum(axis = 1)

#subset the data to only include the country, year, and total adult population.
male_adult = male_df[["country", "Year", "adult"]]
female_adult = female_df[["country", "Year", "adult"]]

#combine the male and female data
sexes_df = male_adult.merge(female_adult, on = ["country", "Year"],
                            suffixes = ["_male", "_female"], how = "left")

#calculate the total population (male + female)
sexes_df["pop"] = sexes_df["adult_male"] + sexes_df["adult_female"]
#calculate the proportion of the population that is male
sexes_df["prop_male"] = sexes_df["adult_male"]/sexes_df["pop"]
#calculate the proportion of the population that is female
sexes_df["prop_female"] = sexes_df["adult_female"]/sexes_df["pop"]

# %% load in the Charmes data

#load in the Charmes 2019 and Charmes 2015 data
charmes2019 = pd.read_excel(".../Charmes2019_unpaid_paid_work.xlsx", sheet_name = "time_use")
charmes2015 = pd.read_excel(".../Charmes_2015.xlsx", sheet_name = "Stata")

#keep the data that already are sex-aggregated for use at the end.
ch2015_both = charmes2015[charmes2015["sex"] == "both"]

#remove the rows in Charmes 2015 when sex is not male or female, but both.
charmes2015 = charmes2015[charmes2015["sex"] != "both"]

#combine charmes 2015 and 2019 into a single dataset
charmes_time = charmes2019.merge(charmes2015, on = ["country", "sex"],
                                 suffixes = ["_2019", "_2015"], how = "outer")

#keep only a subset of the columns
charmes_time = charmes_time[["country", "sex", "geo_2019", "unpaid_total", "paid",
                             "min_leisure", "min_other"]]

#only keep countries in Charmes that are also in IHME
charmes_time = charmes_time[charmes_time["country"].isin(countries.country.unique())]

#for a couple countries (e.g., Cambodia, Uruguay) the "paid" time for one or both
#sexes is 0. This seems impossible, so we set those to na (i.e, missing).
charmes_time.loc[charmes_time["paid"] == 0, "paid"] = np.nan

charmes_time = charmes_time.merge(countries, on = "country", how = "left")

charmes_time.loc[(charmes_time["wb_inc_group"] == "Upper middle income") | (charmes_time["wb_inc_group"] == "Lower middle income"), "wb_inc_group"] = "Middle income"

charmes_time["geo_income"] = charmes_time[["geo_2019", "wb_inc_group"]].astype(str).apply(lambda x: "_".join(x), axis=1)

#create a dataframe that only contains countries with missing data
charmes_missing = charmes_time[charmes_time.isna().any(axis=1)]
#create a dataframe that only contains countries without missing data.
charmes_full = charmes_time.dropna()

charmes_full = charmes_full.replace(country_dict)

#get a region-sex average value for each type of time.
charmes_paid = charmes_full.groupby(['sex', 'geo_income'])['paid'].mean().reset_index()
charmes_unpaid = charmes_full.groupby(['sex', 'geo_income'])['unpaid_total'].mean().reset_index()
charmes_leisure = charmes_full.groupby(['sex', 'geo_income'])['min_leisure'].mean().reset_index()
charmes_other = charmes_full.groupby(['sex', 'geo_income'])['min_other'].mean().reset_index()

#combine those averages into a single dataset
charmes_avg = pd.concat([charmes_paid, charmes_unpaid, charmes_leisure, charmes_other], axis = 1)
charmes_avg = charmes_avg.loc[:,~charmes_avg.columns.duplicated()]

countries_need_attn = []
#create a function that fills in the missing Charmes data.
def map_charmes_time(country):
    """
    Fills in missing data for countries with some data in Charmes 2019.

    Parameters
    ----------
    country : string
        Target country.

    Returns
    -------
    charmes_time : dataframe
        A dataframe containing all the Charmes time use data.

    """
    global charmes_time
    if country in charmes_missing.country.unique():
        country_df = charmes_time[charmes_time["country"] == country]
        missing_df = country_df[country_df.isna().any(axis=1)]
        geo = country_df["geo_income"].values[0]
        #we have no countries with leisure/other time for "Arab countries" or "North Africa" regions. As such, we assign
        #those countries to Central and Western Asia and Sub-Saharan Africa, respectively.
        if "Arab countries" in geo:
            geo = geo.replace("Arab countries", "Central and Western Asia")
        elif "North Africa" in geo:
            geo = geo.replace("North Africa", "Sub-Saharan Africa")
        for sex in missing_df.sex.unique():
            missing_data = missing_df[missing_df["sex"] == sex]
            missing_cols = missing_data[["unpaid_total", "paid"]].columns[missing_data[["unpaid_total", "paid"]].isna().any()].tolist()
            for col in missing_cols:
                try:
                    data_col = charmes_avg.loc[(charmes_avg["geo_income"] == geo) & (charmes_avg["sex"] == sex), col].values[0]
                    charmes_time.loc[(charmes_time["country"] == country) & (charmes_time["sex"] == sex) , col] = data_col
                except:
                    countries_need_attn.append(country)
        return charmes_time
    else:
        pass

#fill in data for any and all countries in Charmes that have missing data.
for c in charmes_time.country.unique():
    map_charmes_time(c)
    
charmes_time.loc[(charmes_time["country"] == "Cambodia") & (charmes_time["sex"] == "men"), "paid"] = charmes_time.loc[(charmes_time["country"] == "Thailand") & (charmes_time["sex"] == "men"), "paid"].values[0]

# %% map charmes time to non-charmes countries

#calculate the region-sex average for each type of time use, where the regions are 
#defined by the WHO regions.
geo_paid = charmes_time.groupby(['sex', 'geo_income'])['paid'].mean().reset_index()
geo_unpaid = charmes_time.groupby(['sex', 'geo_income'])['unpaid_total'].mean().reset_index()
geo_leisure = charmes_time.groupby(['sex', 'geo_income'])['min_leisure'].mean().reset_index()
geo_other = charmes_time.groupby(['sex', 'geo_income'])['min_other'].mean().reset_index()

un_paid = charmes_time.groupby(['sex', 'geo_2019'])['paid'].mean().reset_index()
un_unpaid = charmes_time.groupby(['sex', 'geo_2019'])['unpaid_total'].mean().reset_index()
un_leisure = charmes_time.groupby(['sex', 'geo_2019'])['min_leisure'].mean().reset_index()
un_other = charmes_time.groupby(['sex', 'geo_2019'])['min_other'].mean().reset_index()

empty_countries = countries[~countries["country"].isin(charmes_time.country.unique())]

replace_region_dict = {"Northern Europe": "Northern, Western and Southern Europe",
                       "Western Europe": "Northern, Western and Southern Europe",
                       "Southern Europe": "Northern, Western and Southern Europe",
                       "Latin America and the Caribbean": "Latin America",
                       "Northern Africa": "North Africa",
                       "Central Asia": "Central and Western Asia",
                       "Western Asia": "Central and Western Asia",
                       "South-eastern Asia": "South-Eastern Asia and the Pacific",
                       "Polynesia": "South-Eastern Asia and the Pacific",
                       "Melanesia": "South-Eastern Asia and the Pacific",
                       "Federated States of Micronesia": "South-Eastern Asia and the Pacific"}

empty_countries["un_subregion"] = empty_countries["un_subregion"].replace(replace_region_dict)

empty_countries.loc[(empty_countries["wb_inc_group"] == "Upper middle income") | (empty_countries["wb_inc_group"] == "Lower middle income"), "wb_inc_group"] = "Middle income"

for country in ["Jordan", "Kuwait", "Lebanon", "Saudi Arabia", "Syria", "United Arab Emirates", "Yemen", "Palestine"]:
    empty_countries.loc[empty_countries["country"] == country, "un_subregion"] = "Arab countries"

empty_countries["geo_income"] = empty_countries[["un_subregion", "wb_inc_group"]].astype(str).apply(lambda x: "_".join(x), axis=1)
    
#create a function that fills in the data for IHME countries not in Charmes.
time_use_sex = charmes_time.copy()
issue_countries = []
def map_time_use(country):
    """
    Maps time use from countries in the Charmes' data to countries in IHME without
    time use data.

    Parameters
    ----------
    country : string
        A string referring to the target country to add time use values to.

    Returns
    -------
    time_use_sex : dataframe
        A dataframe containing the Charmes time use data and the mapped time use
        data for countries from IHME.

    """
    global time_use_sex
    if country not in time_use_sex.country.unique():
        who_region = empty_countries.loc[empty_countries["country"] == country, "who_region"].values[0]
        un_region = empty_countries.loc[empty_countries["country"] == country, "un_subregion"].values[0]
        wb_inc_group = empty_countries.loc[empty_countries["country"] == country, "wb_inc_group"].values[0]
        geo_region = empty_countries.loc[empty_countries["country"] == country, "geo_income"].values[0]
        if geo_region in geo_paid.geo_income.unique():
            m_paid = geo_paid.loc[(geo_paid["geo_income"] == geo_region) & (geo_paid["sex"] == "men"), "paid"].values[0]
            m_unpaid = geo_unpaid.loc[(geo_unpaid["geo_income"] == geo_region) & (geo_unpaid["sex"] == "men"), "unpaid_total"].values[0]
            m_leisure = geo_leisure.loc[(geo_leisure["geo_income"] == geo_region) & (geo_leisure["sex"] == "men"), "min_leisure"].values[0]
            m_other = geo_other.loc[(geo_other["geo_income"] == geo_region) & (geo_other["sex"] == "men"), "min_other"].values[0]
            w_paid = geo_paid.loc[(geo_paid["geo_income"] == geo_region) & (geo_paid["sex"] == "women"), "paid"].values[0]
            w_unpaid = geo_unpaid.loc[(geo_unpaid["geo_income"] == geo_region) & (geo_unpaid["sex"] == "women"), "unpaid_total"].values[0]
            w_leisure = geo_leisure.loc[(geo_leisure["geo_income"] == geo_region) & (geo_leisure["sex"] == "women"), "min_leisure"].values[0]
            w_other = geo_other.loc[(geo_other["geo_income"] == geo_region) & (geo_other["sex"] == "women"), "min_other"].values[0]
        else:
            m_paid = un_paid.loc[(un_paid["geo_2019"] == un_region) & (un_paid["sex"] == "men"), "paid"].values[0]
            m_unpaid = un_unpaid.loc[(un_unpaid["geo_2019"] == un_region) & (un_unpaid["sex"] == "men"), "unpaid_total"].values[0]
            m_leisure = un_leisure.loc[(un_leisure["geo_2019"] == un_region) & (un_leisure["sex"] == "men"), "min_leisure"].values[0]
            m_other = un_other.loc[(un_other["geo_2019"] == un_region) & (un_other["sex"] == "men"), "min_other"].values[0]
            w_paid = un_paid.loc[(un_paid["geo_2019"] == un_region) & (un_paid["sex"] == "women"), "paid"].values[0]
            w_unpaid = un_unpaid.loc[(un_unpaid["geo_2019"] == un_region) & (un_unpaid["sex"] == "women"), "unpaid_total"].values[0]
            w_leisure = un_leisure.loc[(un_leisure["geo_2019"] == un_region) & (un_leisure["sex"] == "women"), "min_leisure"].values[0]
            w_other = un_other.loc[(un_other["geo_2019"] == un_region) & (un_other["sex"] == "women"), "min_other"].values[0]
        m_row = pd.Series([country, "men", geo_region, m_unpaid, m_paid, m_leisure, m_other, un_region, who_region, wb_inc_group, geo_region],
                          index = time_use_sex.columns)
        w_row = pd.Series([country, "women", geo_region, w_unpaid, w_paid, w_leisure, w_other, un_region, who_region, wb_inc_group, geo_region],
                          index = time_use_sex.columns)
        time_use_sex = pd.concat([time_use_sex, pd.DataFrame([m_row])], ignore_index=True)
        time_use_sex = pd.concat([time_use_sex, pd.DataFrame([w_row])], ignore_index=True)
        return time_use_sex
    else:
        pass
    
#fill in the data for any and all countries in IHME that are not in Charmes.
for c in empty_countries.country.unique():
    try:
        map_time_use(c)
    except:
        issue_countries.append(c)

# %% combine lifetables data, charmes data, and OECD data for comparison

#add an empty column that will be filled in with proportions of population by sex.
time_use_sex["prop"] = np.nan

countries_missing = []
#fill in those proportions
for c in time_use_sex.country.unique():
    try:
        time_use_sex.loc[(time_use_sex["country"] == c) & (time_use_sex["sex"] == "men"), "prop"] = (
            sexes_df.loc[sexes_df["country"] == c, "prop_male"].values[0])
        time_use_sex.loc[(time_use_sex["country"] == c) & (time_use_sex["sex"] == "women"), "prop"] = (
            sexes_df.loc[sexes_df["country"] == c, "prop_female"].values[0])
    except:
        countries_missing.append(c)

#sort the dataframe
time_use_sex = time_use_sex.sort_values(["country", "sex"])

#calculate the weighted averages for all types of time use, where the weights are the proportions of
#male and female people in the population.
weighted_paid = time_use_sex.groupby("country").apply(lambda x: np.average(x.paid, weights=x.prop))
weighted_unpaid = time_use_sex.groupby("country").apply(lambda x: np.average(x.unpaid_total, weights=x.prop))
weighted_leisure = time_use_sex.groupby("country").apply(lambda x: np.average(x.min_leisure, weights=x.prop))
weighted_other = time_use_sex.groupby("country").apply(lambda x: np.average(x.min_other, weights=x.prop))
            
#combine all of these weighted averages into a single dataset.
time_use_df = pd.concat([weighted_paid, weighted_unpaid, weighted_leisure, weighted_other], axis=1)

#format the data by adding easily interpretable column names.
time_use_df.columns = ["paid", "unpaid", "leisure", "other"]
time_use_df = time_use_df.reset_index()

#use the Charmes 2015 data where sex is "both" to fill in the leisure and other time
for c in ch2015_both.country.unique():
    time_use_df.loc[time_use_df["country"] == c, "leisure"] = ch2015_both.loc[ch2015_both["country"] == c, "min_leisure"].values[0]
    time_use_df.loc[time_use_df["country"] == c, "other"] = ch2015_both.loc[ch2015_both["country"] == c, "min_other"].values[0]

# only keep the relevant columns for this analysis
time_use_df = time_use_df[["country", "paid", "unpaid"]]

# save the output
time_use_df.to_excel(".../time_use_data.xlsx", index = False)
